#include "centre.h"
#include <stdio.h>
#include <string.h>

/* ------------------------------------------------------------ */
/* Ajouter un centre                                             */
/* ------------------------------------------------------------ */
int centre_ajouter(const char *filename, centre c)
{
    FILE *f = fopen(filename, "a");
    if (!f) return 0;

    fprintf(f, "%d \"%s\" \"%s\" %d %d %d %d %d\n",
            c.id, c.nom, c.adresse, c.nb_salle, c.capacite,
            c.nb_coachs, c.nb_membres, c.etat);

    fclose(f);
    return 1;
}

/* ------------------------------------------------------------ */
/* Modifier un centre                                            */
/* ------------------------------------------------------------ */
int centre_modifier(const char *filename, int id, centre nouv)
{
    int tr = 0;
    centre c;
    FILE *f = fopen(filename, "r");
    FILE *tmp = fopen("tmp_centre.txt", "w");
    if (!f || !tmp) { if(f) fclose(f); if(tmp) fclose(tmp); return 0; }

    while (fscanf(f, "%d \"%63[^\"]\" \"%127[^\"]\" %d %d %d %d %d\n",
                  &c.id, c.nom, c.adresse, &c.nb_salle, &c.capacite,
                  &c.nb_coachs, &c.nb_membres, &c.etat) == 8)
    {
        if (c.id == id) {
            fprintf(tmp, "%d \"%s\" \"%s\" %d %d %d %d %d\n",
                    nouv.id, nouv.nom, nouv.adresse, nouv.nb_salle, nouv.capacite,
                    nouv.nb_coachs, nouv.nb_membres, nouv.etat);
            tr = 1;
        } else {
            fprintf(tmp, "%d \"%s\" \"%s\" %d %d %d %d %d\n",
                    c.id, c.nom, c.adresse, c.nb_salle, c.capacite,
                    c.nb_coachs, c.nb_membres, c.etat);
        }
    }

    fclose(f);
    fclose(tmp);
    remove(filename);
    rename("tmp_centre.txt", filename);
    return tr;
}

/* ------------------------------------------------------------ */
/* Supprimer un centre                                           */
/* ------------------------------------------------------------ */
int centre_supprimer(const char *filename, int id)
{
    int tr = 0;
    centre c;
    FILE *f = fopen(filename, "r");
    FILE *tmp = fopen("tmp_centre.txt", "w");
    if (!f || !tmp) { if(f) fclose(f); if(tmp) fclose(tmp); return 0; }

    while (fscanf(f, "%d \"%63[^\"]\" \"%127[^\"]\" %d %d %d %d %d\n",
                  &c.id, c.nom, c.adresse, &c.nb_salle, &c.capacite,
                  &c.nb_coachs, &c.nb_membres, &c.etat) == 8)
    {
        if (c.id == id) tr = 1;
        else
            fprintf(tmp, "%d \"%s\" \"%s\" %d %d %d %d %d\n",
                    c.id, c.nom, c.adresse, c.nb_salle, c.capacite,
                    c.nb_coachs, c.nb_membres, c.etat);
    }

    fclose(f);
    fclose(tmp);
    remove(filename);
    rename("tmp_centre.txt", filename);
    return tr;
}

/* ------------------------------------------------------------ */
/* Rechercher un centre par ID                                   */
/* ------------------------------------------------------------ */
centre centre_rechercher(const char *filename, int id)
{
    centre c;
    c.id = -1;

    FILE *f = fopen(filename, "r");
    if (!f) return c;

    while (fscanf(f, "%d \"%63[^\"]\" \"%127[^\"]\" %d %d %d %d %d\n",
                  &c.id, c.nom, c.adresse, &c.nb_salle, &c.capacite,
                  &c.nb_coachs, &c.nb_membres, &c.etat) == 8)
    {
        if (c.id == id) { fclose(f); return c; }
    }

    fclose(f);
    c.id = -1;
    return c;
}

/* ------------------------------------------------------------ */
/* Enregistrer un centre (ajouter ou modifier automatiquement)  */
/* ------------------------------------------------------------ */
int centre_enregistrer(const char *filename, centre c)
{
    centre cur = centre_rechercher(filename, c.id);
    if (cur.id == -1)
        return centre_ajouter(filename, c);
    return centre_modifier(filename, c.id, c);
}

/* ------------------------------------------------------------ */
/* Annuler opération (placeholder)                               */
/* ------------------------------------------------------------ */
int centre_annuler(const char *filename, int id)
{
    (void)filename; (void)id;
    return 1;
}

/* ------------------------------------------------------------ */
/* Afficher tous les centres dans le TreeView                   */
/* ------------------------------------------------------------ */
void centre_afficher(GtkWidget *treeview)
{
    GtkListStore *store;
    GtkTreeIter iter;
    GtkCellRenderer *renderer;
    GtkTreeViewColumn *column;
    FILE *f;
    centre c;

    store = gtk_list_store_new(8,
                               G_TYPE_INT, G_TYPE_STRING, G_TYPE_STRING,
                               G_TYPE_INT, G_TYPE_INT,
                               G_TYPE_INT, G_TYPE_INT, G_TYPE_INT);

    f = fopen("centre.txt", "r");
    if (f) {
        while (fscanf(f, "%d \"%63[^\"]\" \"%127[^\"]\" %d %d %d %d %d",
                      &c.id, c.nom, c.adresse, &c.nb_salle, &c.capacite,
                      &c.nb_coachs, &c.nb_membres, &c.etat) == 8)
        {
            gtk_list_store_append(store, &iter);
            gtk_list_store_set(store, &iter,
                               0, c.id,
                               1, c.nom,
                               2, c.adresse,
                               3, c.nb_salle,
                               4, c.capacite,
                               5, c.nb_coachs,
                               6, c.nb_membres,
                               7, c.etat,
                               -1);
        }
        fclose(f);
    }

    GList *cols = gtk_tree_view_get_columns(GTK_TREE_VIEW(treeview));
    if (!cols) {
        renderer = gtk_cell_renderer_text_new();
        const char *titles[] = {"ID", "Nom", "Adresse", "Salles",
                                "Capacité", "Coachs", "Membres", "État"};
        for (int i = 0; i < 8; i++) {
            column = gtk_tree_view_column_new_with_attributes(titles[i], renderer, "text", i, NULL);
            gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);
        }
    }
    g_list_free(cols);

    gtk_tree_view_set_model(GTK_TREE_VIEW(treeview), GTK_TREE_MODEL(store));
    g_object_unref(store);
}

/* ------------------------------------------------------------ */
/* Afficher un seul centre après recherche                      */
/* ------------------------------------------------------------ */
void centre_afficher_un(GtkWidget *treeview, centre c)
{
    GtkListStore *store;
    GtkTreeIter iter;

    store = gtk_list_store_new(8,
                               G_TYPE_INT, G_TYPE_STRING, G_TYPE_STRING,
                               G_TYPE_INT, G_TYPE_INT,
                               G_TYPE_INT, G_TYPE_INT, G_TYPE_INT);

    if (c.id != -1) {
        gtk_list_store_append(store, &iter);
        gtk_list_store_set(store, &iter,
                           0, c.id,
                           1, c.nom,
                           2, c.adresse,
                           3, c.nb_salle,
                           4, c.capacite,
                           5, c.nb_coachs,
                           6, c.nb_membres,
                           7, c.etat,
                           -1);
    }

    gtk_tree_view_set_model(GTK_TREE_VIEW(treeview), GTK_TREE_MODEL(store));
    g_object_unref(store);
}
void centre_stats_creer_colonnes(GtkWidget *treeview)
{
    GtkCellRenderer *renderer;
    GtkTreeViewColumn *column;

    // Colonne : Nom du centre
    renderer = gtk_cell_renderer_text_new();
    column = gtk_tree_view_column_new_with_attributes("Centre",
                                                      renderer,
                                                      "text", 0,
                                                      NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);

    // Colonne : Nombre de Membres
    renderer = gtk_cell_renderer_text_new();
    column = gtk_tree_view_column_new_with_attributes("Membres",
                                                      renderer,
                                                      "text", 1,
                                                      NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);
}

void centre_stats_afficher(GtkWidget *treeview)
{
    GtkListStore *store;
    GtkTreeIter iter;

    store = gtk_list_store_new(3, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT);

    FILE *f = fopen("centre.txt", "r");
    if (!f) return;

    centre c;

    while (fscanf(f, "%d %s %s %d %d %d %d %d",
                  &c.id, c.nom, c.adresse, &c.nb_salle,
                  &c.capacite, &c.nb_coachs, &c.nb_membres, &c.etat) == 8)
    {
        gtk_list_store_append(store, &iter);
        gtk_list_store_set(store, &iter,
                           0, c.id,
                           1, c.nb_membres,
                           2, c.nb_coachs,
                           -1);
    }

    fclose(f);

    gtk_tree_view_set_model(GTK_TREE_VIEW(treeview), GTK_TREE_MODEL(store));
}


