#ifndef ENTRAINEURC_H_INCLUDED
#define ENTRAINEURC_H_INCLUDED

#include <stdio.h>

/* Structure entraineur (cohérente avec entraineur.c et GTK) */
typedef struct
{
    int id;
    char nom[50];
    char prenom[50];
    char adresse[100];
    char telephone[20];
    char horaire[50];
    char specialite[50];
    int centre_id;
} entraineur;

/* Fonctions */
int entraineur_ajouter(const char *filename, entraineur e);

#endif /* ENTRAINEURC_H_INCLUDED */

