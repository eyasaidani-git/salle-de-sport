#ifndef CENTRE_H
#define CENTRE_H

#include <gtk/gtk.h>

typedef struct
{
    int id;
    char nom[64];
    char adresse[128];
    int nb_salle;
    int capacite;
    int nb_coachs;
    int nb_membres;
    int etat;
} centre;

/* Gestion des centres */
int centre_ajouter(const char *filename, centre c);
int centre_modifier(const char *filename, int id, centre nouv);
int centre_supprimer(const char *filename, int id);
centre centre_rechercher(const char *filename, int id);  // recherche par ID
int centre_enregistrer(const char *filename, centre c);
int centre_annuler(const char *filename, int id);

/* Affichage GTK */
void centre_afficher(GtkWidget *treeview);      // affiche tous
void centre_afficher_un(GtkWidget *treeview, centre c); // affiche 1 centre
void centre_stats_creer_colonnes(GtkWidget *treeview);
void centre_stats_afficher(GtkWidget *treeview);


#endif
