#include "entraineurc.h"
#include <stdlib.h>

int entraineur_ajouter(const char *filename, entraineur e)
{
    FILE *file = fopen(filename, "a");
    if (file == NULL)
        return 0;

    fprintf(file, "%d;%s;%s;%s;%s;%s;%s;%d\n",
            e.id,
            e.nom,
            e.prenom,
            e.adresse,
            e.telephone,
            e.horaire,
            e.specialite,
            e.centre_id);

    fclose(file);
    return 1;
}

