#ifndef MEMBRES_H_INCLUDED
#define MEMBRES_H_INCLUDED
#include <stdio.h>

typedef struct
{
    int id;
    char nom[30];
    char prenom[30];
    char tel[9];                    
    char email[80];          
    int age;                        
    char sexe;                      
    char maladie[80];      
    int abonnement;                
    int jour, mois, annee;         
    int etat;                      
    int centre;                  
    int assurance;                
    int proches;                   
} membre;

int is_all_digits_custom(const char *s);
int valider_tel_tn(const char *tel);
int valider_email_gmail(const char *email);
int valider_age(int age);
int valider_sexe(char s);
int valider_abonnement(int a);
int valider_date(int j, int m, int a);
int valider_centre(int c);
int valider_proches(int p);

int is_bissextile(int a);
int jours_dans_mois(int m, int a);
int date_to_days_from_2025(int j, int m, int a);

int etat_abonnement_depuis(
    int j_insc, int m_insc, int a_insc,
    int j_auj,  int m_auj,  int a_auj
);

int lire_membre(FILE *f, membre *m);
void ecrire_membre(FILE *f, membre m);

int id_existe(const char *filename, int id);
int generer_nouvel_id(const char *filename);

int ajouter_membre(const char *filename, membre m,
                   int j_auj, int m_auj, int a_auj);

int ajouter_membre_autoid(const char *filename, membre m,
                          int j_auj, int m_auj, int a_auj);

int modifier_membre(const char *filename, int id, membre nouv,
                    int j_auj, int m_auj, int a_auj);

int supprimer_membre(const char *filename, int id);

membre chercher_membre_id(const char *filename, int id);


int chercher_ids_par_nom(const char *filename,
                         const char *nom,
                         const char *prenom,
                         int ids[], int max_ids);

void afficher_membre(membre m);
void afficher_resume_membre(membre m);

int maj_etats_fichier(const char *filename,
                      int j_auj, int m_auj, int a_auj);

#endif

