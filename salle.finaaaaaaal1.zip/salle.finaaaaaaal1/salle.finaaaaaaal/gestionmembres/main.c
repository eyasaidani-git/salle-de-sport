#include <stdio.h>
#include <string.h>
#include "membres.h"

void saisir_membre(membre *m)
{
    printf("Nom: ");
    scanf("%s", m->nom);

    printf("Prenom: ");
    scanf("%s", m->prenom);

    printf("Telephone : ");
    scanf("%s", m->tel);

    printf("Email (@gmail.com): ");
    scanf("%s", m->email);

    printf("Age : ");
    scanf("%d", &m->age);

    printf("Sexe (H/F): ");
    scanf(" %c", &m->sexe);

    printf("Maladie (none si aucune): ");
    scanf("%s", m->maladie);

    printf("Abonnement:\n");
    printf("1- Mensuelle (Demi-journee)\n");
    printf("2- Mensuelle (Journee)\n");
    printf("3- Annuelle (Demi-journee)\n");
    printf("4- Annuelle (Journee)\n");
    scanf("%d", &m->abonnement);

    printf("Centre sportif:\n");
    printf("1- Next level spot (manouba)\n");
    printf("2- Next level spot (marsa)\n");
    printf("3- Next level spot (bardo)\n");
    printf("4- Next level spot (ariana)\n");
    printf("5- Next level spot (mourouj)\n");
    printf("6- Next level spot (ben arous)\n");
    scanf("%d", &m->centre);

    printf("Assurance (1=Oui, 0=Non): ");
    scanf("%d", &m->assurance);

    printf("Nombre de proches: ");
    scanf("%d", &m->proches);
}

int choisir_id_par_nom(const char *filename)
{
    char nom[30], prenom[30];
    int ids[200];
    int n, i;
    int choix_id;

    printf("Nom: ");
    scanf("%s", nom);

    printf("Prenom (0 pour ignorer): ");
    scanf("%s", prenom);

    if (strcmp(prenom, "0") == 0) prenom[0] = '\0';

    n = chercher_ids_par_nom(filename, nom, prenom, ids, 200);

    if (n <= 0)
    {
        printf("Aucun membre trouve.\n");
        return -1;
    }

    printf("\n Liste des membres trouvés (%d) \n", n);

    for (i = 0; i < n && i < 200; i++)
    {
        membre m = chercher_membre_id(filename, ids[i]);
        afficher_resume_membre(m);
    }

    printf("\nEntrer l'ID exact a choisir: ");
    scanf("%d", &choix_id);

    if (!id_existe(filename, choix_id))
    {
        printf("ID invalide.\n");
        return -1;
    }

    return choix_id;
}

int main()
{
    const char *F = "membres.txt";
    int choix, mode, id;
    int j_auj, m_auj, a_auj;

    printf("Donner la date d'aujourd'hui (j m a): ");
    scanf("%d %d %d", &j_auj, &m_auj, &a_auj);

    maj_etats_fichier(F, j_auj, m_auj, a_auj);

    do
    {
        printf("\n-Menu membres :\n");
        printf("1. Ajouter membre\n");
        printf("2. Rechercher membre\n");
        printf("3. Modifier membre\n");
        printf("4. Supprimer membre\n");
        printf("0. Quitter\n");
        printf("Choix: ");
        scanf("%d", &choix);

        switch (choix)
        {
        case 1:
        {
            membre m;
            memset(&m, 0, sizeof(m));
            saisir_membre(&m);

            if (ajouter_membre_autoid(F, m, j_auj, m_auj, a_auj))
                printf("Ajout fait (ID auto).\n");
            else
                printf("Eched d'ajout (validation/fichier).\n");
            break;
        }

        case 2: 
        {
            printf("Rechercher par: 1-ID, 2-NOM : ");
            scanf("%d", &mode);

            if (mode == 1)
            {
                printf("ID: ");
                scanf("%d", &id);
            }
            else
            {
                id = choisir_id_par_nom(F);
                if (id == -1) break;
            }

            {
                membre m = chercher_membre_id(F, id);
                afficher_membre(m);
            }
            break;
        }

        case 3:
        {
            printf("Modifier par: 1-ID, 2-NOM : ");
            scanf("%d", &mode);

            if (mode == 1)
            {
                printf("ID: ");
                scanf("%d", &id);
                if (!id_existe(F, id))
                {
                    printf(" ID introuvable.\n");
                    break;
                }
            }
            else
            {
                id = choisir_id_par_nom(F);
                if (id == -1) break;
            }

            {
                membre oldm = chercher_membre_id(F, id);
                printf("\nAncien membre:\n");
                afficher_membre(oldm);

                membre nouv;
                memset(&nouv, 0, sizeof(nouv));

                printf("\n Nouvelle saisie:\n");
                saisir_membre(&nouv);
                nouv.jour  = oldm.jour;
                nouv.mois  = oldm.mois;
                nouv.annee = oldm.annee;

                if (modifier_membre(F, id, nouv, j_auj, m_auj, a_auj))
                    printf("Modification faite .\n");
                else
                    printf("Echec de modification.\n");
            }
            break;
        }

        case 4:
        {
            printf("Supprimer par: 1-ID, 2-NOM : ");
            scanf("%d", &mode);

            if (mode == 1)
            {
                printf("ID: ");
                scanf("%d", &id);
            }
            else
            {
                id = choisir_id_par_nom(F);
                if (id == -1) break;
            }

            if (supprimer_membre(F, id))
                printf(" Suppression faite.\n");
            else
                printf("Echec de suppression (ID introuvable).\n");

            break;
        }

        case 0:
            printf("Au revoir.\n");
            break;

        default:
            printf("Choix invalide.\n");
        }

    } while (choix != 0);

    return 0;
}

