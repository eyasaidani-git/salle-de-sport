#include "membres.h"
#include <string.h>
#include <ctype.h>

int is_all_digits_custom(const char *s)
{
    int i;
    if (!s) return 0;
    for (i = 0; s[i] != '\0'; i++)
        if (s[i] < '0' || s[i] > '9') return 0;
    return 1;
}

int valider_tel_tn(const char *tel)
{
    if (!tel) return 0;
    if ((int)strlen(tel) != 8) return 0;
    return is_all_digits_custom(tel);
}

int valider_email_gmail(const char *email)
{
    const char *suffix = "@gmail.com";
    int le, ls;
    if (!email) return 0;

    le = (int)strlen(email);
    ls = (int)strlen(suffix);
    if (le <= ls) return 0;
    if (strcmp(email + (le - ls), suffix) != 0) return 0;
    if (email[0] == '@') return 0;
    return 1;
}

int valider_age(int age) { return (age >= 11 && age <= 90); }

int valider_sexe(char s)
{
    s = (char)toupper((unsigned char)s);
    return (s == 'H' || s == 'F');
}

int valider_abonnement(int a) { return (a >= 1 && a <= 4); }

int valider_date(int j, int m, int a)
{
    int maxj, bissex;
    if (a < 2025) return 0;
    if (m < 1 || m > 12) return 0;
    if (j < 1 || j > 31) return 0;

    maxj = 31;
    if (m == 4 || m == 6 || m == 9 || m == 11) maxj = 30;

    if (m == 2)
    {
        bissex = ((a % 4 == 0 && a % 100 != 0) || (a % 400 == 0));
        maxj = bissex ? 29 : 28;
    }
    return (j <= maxj);
}

int valider_centre(int c)  { return (c >= 1 && c <= 6); }
int valider_proches(int p) { return (p >= 0); }

int is_bissextile(int a)
{
    return ((a % 4 == 0 && a % 100 != 0) || (a % 400 == 0));
}

int jours_dans_mois(int m, int a)
{
    if (m == 2) return is_bissextile(a) ? 29 : 28;
    if (m == 4 || m == 6 || m == 9 || m == 11) return 30;
    return 31;
}

int date_to_days_from_2025(int j, int m, int a)
{
    int days = 0;
    int yy, mm;

    for (yy = 2025; yy < a; yy++)
        days += is_bissextile(yy) ? 366 : 365;

    for (mm = 1; mm < m; mm++)
        days += jours_dans_mois(mm, a);

    days += (j - 1);
    return days;
}

int etat_abonnement_depuis(
    int j_insc, int m_insc, int a_insc,
    int j_auj,  int m_auj,  int a_auj
)
{
    int d_insc, d_auj, diff;

    if (!valider_date(j_insc, m_insc, a_insc)) return 0;
    if (!valider_date(j_auj,  m_auj,  a_auj))  return 0;

    d_insc = date_to_days_from_2025(j_insc, m_insc, a_insc);
    d_auj  = date_to_days_from_2025(j_auj,  m_auj,  a_auj);

    diff = d_auj - d_insc;

    if (diff <= 30) return 1;
    return 0;
}

int lire_membre(FILE *f, membre *m)
{
    int r;
    if (!f || !m) return 0;

    r = fscanf(
        f,
        "%d %29s %29s %8s %79s %d %c %79s %d %d %d %d %d %d %d %d\n",
        &m->id,
        m->nom,
        m->prenom,
        m->tel,
        m->email,
        &m->age,
        &m->sexe,
        m->maladie,
        &m->abonnement,
        &m->jour,
        &m->mois,
        &m->annee,
        &m->etat,
        &m->centre,
        &m->assurance,
        &m->proches
    );

    return (r == 16);
}

void ecrire_membre(FILE *f, membre m)
{
    fprintf(
        f,
        "%d %s %s %s %s %d %c %s %d %d %d %d %d %d %d %d\n",
        m.id,
        m.nom,
        m.prenom,
        m.tel,
        m.email,
        m.age,
        m.sexe,
        (strlen(m.maladie) ? m.maladie : "none"),
        m.abonnement,
        m.jour,
        m.mois,
        m.annee,
        m.etat,
        m.centre,
        m.assurance,
        m.proches
    );
}

int id_existe(const char *filename, int id)
{
    FILE *f;
    membre cur;

    f = fopen(filename, "r");
    if (!f) return 0;

    while (lire_membre(f, &cur))
    {
        if (cur.id == id)
        {
            fclose(f);
            return 1;
        }
    }
    fclose(f);
    return 0;
}

int generer_nouvel_id(const char *filename)
{
    FILE *f;
    membre m;
    int maxid = 0;
    int nouv;

    f = fopen(filename, "r");
    if (f)
    {
        while (lire_membre(f, &m))
            if (m.id > maxid) maxid = m.id;
        fclose(f);
    }

    nouv = maxid + 1;

    while (id_existe(filename, nouv))
        nouv++;

    return nouv;
}

int ajouter_membre(const char *filename, membre m,
                   int j_auj, int m_auj, int a_auj)
{
    FILE *f;

    if (id_existe(filename, m.id)) return 0;

    if (!valider_tel_tn(m.tel)) return 0;
    if (!valider_email_gmail(m.email)) return 0;
    if (!valider_age(m.age)) return 0;
    if (!valider_sexe(m.sexe)) return 0;
    if (!valider_abonnement(m.abonnement)) return 0;
    if (!valider_date(m.jour, m.mois, m.annee)) return 0;
    if (!valider_centre(m.centre)) return 0;
    if (!valider_proches(m.proches)) return 0;
    if (!valider_date(j_auj, m_auj, a_auj)) return 0;

    m.sexe = (char)toupper((unsigned char)m.sexe);
    m.etat = etat_abonnement_depuis(m.jour, m.mois, m.annee, j_auj, m_auj, a_auj);

    f = fopen(filename, "a");
    if (!f) return 0;

    ecrire_membre(f, m);
    fclose(f);
    return 1;
}

int ajouter_membre_autoid(const char *filename, membre m,
                          int j_auj, int m_auj, int a_auj)
{
    m.id = generer_nouvel_id(filename);
    m.jour  = j_auj;
    m.mois  = m_auj;
    m.annee = a_auj;

    m.etat = etat_abonnement_depuis(m.jour, m.mois, m.annee, j_auj, m_auj, a_auj);

    return ajouter_membre(filename, m, j_auj, m_auj, a_auj);
}

int modifier_membre(const char *filename, int id, membre nouv,
                    int j_auj, int m_auj, int a_auj)
{
    FILE *f, *f2;
    membre cur;
    int tr = 0;

    f = fopen(filename, "r");
    f2 = fopen("nouv.txt", "w");
    if (!f || !f2)
    {
        if (f) fclose(f);
        if (f2) fclose(f2);
        return 0;
    }

    nouv.id = id;

    if (!valider_tel_tn(nouv.tel) ||
        !valider_email_gmail(nouv.email) ||
        !valider_age(nouv.age) ||
        !valider_sexe(nouv.sexe) ||
        !valider_abonnement(nouv.abonnement) ||
        !valider_date(nouv.jour, nouv.mois, nouv.annee) ||
        !valider_centre(nouv.centre) ||
        !valider_proches(nouv.proches) ||
        !valider_date(j_auj, m_auj, a_auj))
    {
        fclose(f);
        fclose(f2);
        remove("nouv.txt");
        return 0;
    }

    nouv.sexe = (char)toupper((unsigned char)nouv.sexe);
    nouv.etat = etat_abonnement_depuis(nouv.jour, nouv.mois, nouv.annee, j_auj, m_auj, a_auj);

    while (lire_membre(f, &cur))
    {
        if (cur.id == id)
        {
            ecrire_membre(f2, nouv);
            tr = 1;
        }
        else
        {
            ecrire_membre(f2, cur);
        }
    }

    fclose(f);
    fclose(f2);

    remove(filename);
    rename("nouv.txt", filename);

    return tr;
}

int supprimer_membre(const char *filename, int id)
{
    FILE *f, *f2;
    membre cur;
    int tr = 0;

    f = fopen(filename, "r");
    f2 = fopen("nouv.txt", "w");
    if (!f || !f2)
    {
        if (f) fclose(f);
        if (f2) fclose(f2);
        return 0;
    }

    while (lire_membre(f, &cur))
    {
        if (cur.id == id)
            tr = 1;
        else
            ecrire_membre(f2, cur);
    }

    fclose(f);
    fclose(f2);

    remove(filename);
    rename("nouv.txt", filename);

    return tr;
}

membre chercher_membre_id(const char *filename, int id)
{
    FILE *f;
    membre cur, res;
    res.id = -1;

    f = fopen(filename, "r");
    if (!f) return res;

    while (lire_membre(f, &cur))
    {
        if (cur.id == id)
        {
            fclose(f);
            return cur;
        }
    }

    fclose(f);
    return res;
}


int chercher_ids_par_nom(const char *filename,
                         const char *nom,
                         const char *prenom,
                         int ids[], int max_ids)
{
    FILE *f;
    membre cur;
    int cpt = 0;
    int use_prenom = 0;

    if (!filename || !nom || !ids || max_ids <= 0) return 0;

    if (prenom != NULL && prenom[0] != '\0') use_prenom = 1;

    f = fopen(filename, "r");
    if (!f) return 0;

    while (lire_membre(f, &cur))
    {
        if (strcmp(cur.nom, nom) == 0)
        {
            if (!use_prenom || strcmp(cur.prenom, prenom) == 0)
            {
                if (cpt < max_ids)
                    ids[cpt] = cur.id;
                cpt++;
            }
        }
    }

    fclose(f);
    return cpt;
}

void afficher_resume_membre(membre m)
{
    printf("ID=%d | %s %s | Tel:+216 %s | Etat:%s | Centre:%d\n",
           m.id, m.nom, m.prenom, m.tel,
           m.etat ? "Actif" : "Expire",
           m.centre);
}

void afficher_membre(membre m)
{
    if (m.id == -1)
    {
        printf("Membre introuvable.\n");
        return;
    }

    printf("ID: %d\n", m.id);
    printf("Nom: %s\n", m.nom);
    printf("Prenom: %s\n", m.prenom);
    printf("Tel: +216 %s\n", m.tel);
    printf("Email: %s\n", m.email);
    printf("Age: %d\n", m.age);
    printf("Sexe: %c\n", m.sexe);
    printf("Maladie: %s\n", (strlen(m.maladie) ? m.maladie : "none"));
    printf("Abonnement(code): %d\n", m.abonnement);
    printf("Date inscription: %02d/%02d/%04d\n", m.jour, m.mois, m.annee);
    printf("Etat: %s\n", m.etat ? "Actif" : "Expire");
    printf("Centre(code): %d\n", m.centre);
    printf("Assurance: %s\n", m.assurance ? "Oui" : "Non");
    printf("Proches: %d\n", m.proches);
}

int maj_etats_fichier(const char *filename,
                      int j_auj, int m_auj, int a_auj)
{
    FILE *f, *f2;
    membre m;

    f = fopen(filename, "r");
    if (!f) return 0;

    f2 = fopen("nouv.txt", "w");
    if (!f2)
    {
        fclose(f);
        return 0;
    }

    while (lire_membre(f, &m))
    {
        m.etat = etat_abonnement_depuis(m.jour, m.mois, m.annee, j_auj, m_auj, a_auj);
        ecrire_membre(f2, m);
    }

    fclose(f);
    fclose(f2);

    remove(filename);
    rename("nouv.txt", filename);
    return 1;
}

