#ifndef DEMANDE_H_INCLUDED
#define DEMANDE_H_INCLUDED

#include <stdio.h>

typedef struct
{
    char nom[20];        
    char email[20];
    char tel[20];
    char sexe[20];
    char specialite[20]; 
    char centre[20];    
    char niveau[20];
    char dispo_txt[20];  
    int prix;                
} entraineur;

typedef struct
{
    int id;                  
    char nom_m[20];
    char prenom_m[20];
    int centre_code;         
    float poids;              
    float hauteur;            
    int coach_index;          
    char coach_nom[20];
    char coach_spec[20];
    int coach_prix;          
    int dispo;               
    char jours[80];    
} demande;

void centre_code_to_string(int code, char out[20]);
int valider_centre_code(int code); 

int charger_entraineurs(const char *filename, entraineur tab[], int max);
void afficher_entraineurs(const entraineur tab[], int n);

int generer_nouvel_id_demande(const char *filename);
int lire_demande(FILE *f, demande *d);
void ecrire_demande(FILE *f, demande d);

int compter_clients_coach(const char *demande_file, int coach_index);
int coach_est_disponible(const char *demande_file, int coach_index); 

int ajouter_demande(const char *demande_file,
                    const char *entraineurs_file,
                    demande d);

int afficher_toutes_demandes(const char *demande_file);

demande chercher_demande_id(const char *demande_file, int id);

int supprimer_demande(const char *demande_file, int id);

void afficher_demande(demande d);
void afficher_resume_demande(demande d);
int ajouter_demande_si_confirmee(const char *demande_file,
                                const char *entraineurs_file,
                                demande d,
                                int confirmer); 

void afficher_entraineurs_avec_dispo(const entraineur tab[], int n,
                                    const char *demande_file);


#endif

