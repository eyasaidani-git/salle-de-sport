#include "demande.h"
#include <string.h>
#include <stdlib.h>

void centre_code_to_string(int code, char out[20])
{
    if (code == 1) strcpy(out, "Next level spot(manouba)");
    else if (code == 2) strcpy(out, "Next level spot(marsa)");
    else if (code == 3) strcpy(out, "Next level spot(bardo)");
    else if (code == 4) strcpy(out, "Next level spot(ariana)");
    else if (code == 5) strcpy(out, "Next level spot(mourouj)");
    else if (code == 6) strcpy(out, "Next level spot(ben arous)");
    else strcpy(out, "Inconnu");
}

int valider_centre_code(int code)
{
    return (code >= 1 && code <= 6);
}


int charger_entraineurs(const char *filename, entraineur tab[], int max)
{
    FILE *f = fopen(filename, "r");
    char line[512];
    int n = 0;

    if (!f) return 0;

    while (fgets(line, sizeof(line), f) && n < max)
    {
    
        int L = (int)strlen(line);
        if (L > 0 && (line[L-1] == '\n' || line[L-1] == '\r')) line[L-1] = '\0';

    
        entraineur e;
        int prix_tmp = 0;

        int r = sscanf(line,
                       "%[^;];%[^;];%[^;];%[^;];%[^;];%[^;];%[^;];%[^;];%d",
                       e.nom, e.email, e.tel, e.sexe, e.specialite, e.centre,
                       e.niveau, e.dispo_txt, &prix_tmp);

        if (r == 9)
        {
            e.prix = prix_tmp;
            tab[n] = e;
            n++;
        }
    }

    fclose(f);
    return n;
}

void afficher_entraineurs(const entraineur tab[], int n)
{
    int i;
    printf("\n===== Liste des coachs (index) =====\n");
    for (i = 0; i < n; i++)
    {
        printf("%d) %s (%s) | Centre: %s | Prix: %d\n",
               i+1, tab[i].nom, tab[i].specialite, tab[i].centre, tab[i].prix);
    }
}

void afficher_entraineurs_avec_dispo(const entraineur tab[], int n,
                                    const char *demande_file)
{
    int i;
    printf("\n===== Liste des coachs (index) =====\n");
    for (i = 0; i < n; i++)
    {
        int dispo = coach_est_disponible(demande_file, i + 1);
        printf("%d) %s (%s) | Centre: %s | Prix: %d | %s\n",
               i + 1,
               tab[i].nom,
               tab[i].specialite,
               tab[i].centre,
               tab[i].prix,
               dispo ? "Disponible" : "Indisponible");
    }
}

int ajouter_demande_si_confirmee(const char *demande_file,
                                const char *entraineurs_file,
                                demande d,
                                int confirmer)
{
    if (confirmer == 0)
        return 0; 

    return ajouter_demande(demande_file, entraineurs_file, d);
}


int lire_demande(FILE *f, demande *d)
{
    char line[512];
    if (!f || !d) return 0;

    if (!fgets(line, sizeof(line), f)) return 0;

    {
        int L = (int)strlen(line);
        if (L > 0 && (line[L-1] == '\n' || line[L-1] == '\r')) line[L-1] = '\0';
    }

    {
        int r = sscanf(line,
                       "%d;%[^;];%[^;];%d;%f;%f;%d;%[^;];%[^;];%d;%d;%[^;]",
                       &d->id,
                       d->nom_m,
                       d->prenom_m,
                       &d->centre_code,
                       &d->poids,
                       &d->hauteur,
                       &d->coach_index,
                       d->coach_nom,
                       d->coach_spec,
                       &d->coach_prix,
                       &d->dispo,
                       d->jours);
        return (r == 12);
    }
}

void ecrire_demande(FILE *f, demande d)
{
    fprintf(f,
            "%d;%s;%s;%d;%.2f;%.2f;%d;%s;%s;%d;%d;%s\n",
            d.id,
            d.nom_m,
            d.prenom_m,
            d.centre_code,
            d.poids,
            d.hauteur,
            d.coach_index,
            d.coach_nom,
            d.coach_spec,
            d.coach_prix,
            d.dispo,
            (strlen(d.jours) ? d.jours : "Aucun"));
}

int generer_nouvel_id_demande(const char *filename)
{
    FILE *f = fopen(filename, "r");
    demande d;
    int maxid = 0;

    if (!f) return 1;

    while (lire_demande(f, &d))
        if (d.id > maxid) maxid = d.id;

    fclose(f);
    return maxid + 1;
}

int compter_clients_coach(const char *demande_file, int coach_index)
{
    FILE *f = fopen(demande_file, "r");
    demande d;
    int cpt = 0;

    if (!f) return 0;

    while (lire_demande(f, &d))
    {
        if (d.coach_index == coach_index)
            cpt++;
    }

    fclose(f);
    return cpt;
}

int coach_est_disponible(const char *demande_file, int coach_index)
{
    int nb = compter_clients_coach(demande_file, coach_index);
    return (nb < 7) ? 1 : 0;
}


int ajouter_demande(const char *demande_file,
                    const char *entraineurs_file,
                    demande d)
{
    entraineur tab[50];
    int n = charger_entraineurs(entraineurs_file, tab, 50);

    if (n <= 0) return 0;
    if (!valider_centre_code(d.centre_code)) return 0;
    if (d.poids <= 0) return 0;
    if (d.hauteur <= 0) return 0;
    if (d.coach_index < 1 || d.coach_index > n) return 0;

    d.id = generer_nouvel_id_demande(demande_file);

    strcpy(d.coach_nom, tab[d.coach_index - 1].nom);
    strcpy(d.coach_spec, tab[d.coach_index - 1].specialite);
    d.coach_prix = tab[d.coach_index - 1].prix;

    d.dispo = coach_est_disponible(demande_file, d.coach_index);

    {
        FILE *f = fopen(demande_file, "a");
        if (!f) return 0;
        ecrire_demande(f, d);
        fclose(f);
    }

    return 1;
}

int afficher_toutes_demandes(const char *demande_file)
{
    FILE *f = fopen(demande_file, "r");
    demande d;
    int found = 0;

    if (!f)
    {
        printf("Aucune demande (fichier introuvable).\n");
        return 0;
    }

    printf("\nListe des demandes\n");
    while (lire_demande(f, &d))
    {
        afficher_resume_demande(d);
        found = 1;
    }

    fclose(f);

    if (!found) printf("Aucune demande.\n");
    return found;
}

demande chercher_demande_id(const char *demande_file, int id)
{
    FILE *f = fopen(demande_file, "r");
    demande d, res;

    res.id = -1;

    if (!f) return res;

    while (lire_demande(f, &d))
    {
        if (d.id == id)
        {
            fclose(f);
            return d;
        }
    }

    fclose(f);
    return res;
}

int supprimer_demande(const char *demande_file, int id)
{
    FILE *f = fopen(demande_file, "r");
    FILE *f2 = fopen("nouv.txt", "w");
    demande d;
    int tr = 0;

    if (!f || !f2)
    {
        if (f) fclose(f);
        if (f2) fclose(f2);
        return 0;
    }

    while (lire_demande(f, &d))
    {
        if (d.id == id)
            tr = 1;
        else
            ecrire_demande(f2, d);
    }

    fclose(f);
    fclose(f2);

    remove(demande_file);
    rename("nouv.txt", demande_file);

    return tr;
}

void afficher_resume_demande(demande d)
{
    printf("ID=%d | %s %s | Coach=%s(%s) | Prix=%d | %s\n",
           d.id, d.nom_m, d.prenom_m,
           d.coach_nom, d.coach_spec,
           d.coach_prix,
           d.dispo ? "Disponible" : "Indisponible");
}

void afficher_demande(demande d)
{
    char centre[30];

    if (d.id == -1)
    {
        printf("Demande introuvable.\n");
        return;
    }

    centre_code_to_string(d.centre_code, centre);

    printf("\nDemande\n");
    printf("ID: %d\n", d.id);
    printf("Membre: %s %s\n", d.nom_m, d.prenom_m);
    printf("Centre: %s\n", centre);
    printf("Poids: %.2f kg\n", d.poids);
    printf("Hauteur: %.2f m\n", d.hauteur);
    printf("Coach: %s (%s)\n", d.coach_nom, d.coach_spec);
    printf("Prix mensuel: %d\n", d.coach_prix);
    printf("Disponibilite coach: %s\n", d.dispo ? "Disponible" : "Indisponible");
    printf("Jours choisis: %s\n", d.jours);
}

