#include <stdio.h>
#include <string.h>
#include "demande.h"

void saisir_jours(char out[80])
{
    int lun, mar, mer, jeu, ven, sam, dim, tous;
    out[0] = '\0';

    printf("Coche jours (1=Oui,0=Non)\n");
    printf("Tous les jours ? ");
    scanf(" %d", &tous);

    if (tous == 1)
    {
        strcpy(out, "Tous");
        return;
    }

    printf("Lundi: ");    scanf(" %d", &lun);
    printf("Mardi: ");    scanf(" %d", &mar);
    printf("Mercredi: "); scanf(" %d", &mer);
    printf("Jeudi: ");    scanf(" %d", &jeu);
    printf("Vendredi: "); scanf(" %d", &ven);
    printf("Samedi: ");   scanf(" %d", &sam);
    printf("Dimanche: "); scanf(" %d", &dim);

    if (lun) strcat(out, "Lundi,");
    if (mar) strcat(out, "Mardi,");
    if (mer) strcat(out, "Mercredi,");
    if (jeu) strcat(out, "Jeudi,");
    if (ven) strcat(out, "Vendredi,");
    if (sam) strcat(out, "Samedi,");
    if (dim) strcat(out, "Dimanche,");

    {
        int L = (int)strlen(out);
        if (L > 0 && out[L-1] == ',') out[L-1] = '\0';
    }

    if (strlen(out) == 0) strcpy(out, "Aucun");
}

void afficher_centres()
{
    printf("\nCentres:\n");
    printf("1- Next level spot(manouba)\n");
    printf("2- Next level spot(marsa)\n");
    printf("3- Next level spot(bardo)\n");
    printf("4- Next level spot(ariana)\n");
    printf("5- Next level spot(mourouj)\n");
    printf("6- Next level spot(ben arous)\n");
}

int main()
{
    const char *ENT = "entraineurs.txt";
    const char *DEM = "demande.txt";

    int choix;

    do
    {
        printf("\n Menu demande coach privé : \n");
        printf("1. Ajouter une demande\n");
        printf("2. Afficher toutes les demandes\n");
        printf("3. Rechercher une demande \n");
        printf("4. Supprimer une demande \n");
        printf("0. Quitter\n");
        printf("Choix: ");
        scanf(" %d", &choix);

        switch (choix)
        {
        case 1:
        {
            entraineur tab[50];
    		int n = charger_entraineurs(ENT, tab, 50);
    		if (n <= 0)
    		{
        		printf("Erreur: entraineurs.txt introuvable ou vide.\n");
        		break;
    		}

    	printf("\n--- Consultation des coachs ---\n");
    	afficher_entraineurs_avec_dispo(tab, n, DEM);

    	printf("\nVoulez-vous faire une demande ? (1=Oui, 0=Non): ");
    	{
        int want = 0;
        scanf(" %d", &want);

        if (want == 0)
        {
            printf("OK, aucune demande n'a ete enregistree.\n");
            break;
        }
    	}

   	 demande d;
	memset(&d, 0, sizeof(d));

    	printf("Nom membre: ");
    	scanf(" %s", d.nom_m);

    	printf("Prenom membre: ");
    	scanf(" %s", d.prenom_m);

    	afficher_centres();
    	printf("Centre (1..6): ");
    	scanf(" %d", &d.centre_code);

    	printf("Poids (kg): ");
    	scanf(" %f", &d.poids);

    	printf("Hauteur (m): ");
    	scanf(" %f", &d.hauteur);

    	printf("\nChoisir coach (index 1..%d): ", n);
    	scanf(" %d", &d.coach_index);

    	if (d.coach_index < 1 || d.coach_index > n)
    	{
        	printf("Index coach invalide.\n");
        	break;
    	}


    	{
        	int dispo = coach_est_disponible(DEM, d.coach_index);
        	printf("\n--- Coach choisi ---\n");
        	printf("Coach: %s (%s)\n", tab[d.coach_index - 1].nom, tab[d.coach_index - 1].specialite);
        	printf("Prix mensuel: %d\n", tab[d.coach_index - 1].prix);
        	printf("Disponibilite coach: %s\n", dispo ? "Disponible" : "Indisponible");
    	}

    	saisir_jours(d.jours);

    	printf("\nConfirmer la demande ? (1=Oui, 0=Non): ");
    	{
        	int confirmer = 0;
        	scanf(" %d", &confirmer);

        if (confirmer == 0)
        {
            printf("Demande annulee. Rien n'a ete sauvegarde.\n");
            break;
        }

        if (ajouter_demande(DEM, ENT, d))
            printf("Demande ajoutee et sauvegardee dans demande.txt\n");
        else
            printf("Echec ajout (verifie centre/poids/hauteur/fichiers/disponibilite)\n");
    	}

    	break;

        }

        case 2:
            afficher_toutes_demandes(DEM);
            break;

        case 3:
        {
            int id;
            printf("ID demande: ");
            scanf(" %d", &id);
            {
                demande d = chercher_demande_id(DEM, id);
                afficher_demande(d);
            }
            break;
        }

        case 4:
        {
            int id;
            printf("ID demande a supprimer: ");
            scanf(" %d", &id);

            if (supprimer_demande(DEM, id))
                printf("Suppression OK.\n");
            else
                printf("ID introuvable.\n");
            break;
        }

        case 0:
            printf("Au revoir.\n");
            break;

        default:
            printf("Choix invalide.\n");
        }

    } while (choix != 0);

    return 0;
}

