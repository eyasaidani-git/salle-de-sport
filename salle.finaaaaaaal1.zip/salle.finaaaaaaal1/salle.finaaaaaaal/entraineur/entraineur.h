#ifndef ENTRAINEUR_H_INCLUDED
#define ENTRAINEUR_H_INCLUDED

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// NE PAS inclure GTK ici - entraineur.h doit être indépendant de GTK
// #include <gtk/gtk.h>  // NE PAS INCLURE

#define MAX_ID 50
#define MAX_NOM 100
#define MAX_EMAIL 100
#define MAX_TEL 20
#define MAX_SEXE 10
#define MAX_SPECIALITE 100
#define MAX_DISPONIBILITE 50
#define MAX_JOURS 100
#define MAX_CONTRAT 50

typedef struct {
    char id[MAX_ID];
    char nom[MAX_NOM];
    char email[MAX_EMAIL];
    char telephone[MAX_TEL];
    char sexe[MAX_SEXE];
    char specialite[MAX_SPECIALITE];
    char disponibilite[MAX_DISPONIBILITE];
    char jours[MAX_JOURS];
    char contrat[MAX_CONTRAT];
    int heures_semaine;
} Entraineur;

// Fonctions de gestion des entraîneurs (sans GTK)
int ajouter_entraineur(char *filename, Entraineur e);
int modifier_entraineur(char *filename, char *id, Entraineur nouv);
int supprimer_entraineur(char *filename, char *id);
Entraineur chercher_entraineur(char *filename, char *id);
int compter_entraineurs(char *filename);
void afficher_tous_entraineurs(char *filename);

// Déclaration forward pour éviter d'inclure GTK
struct _GtkWidget;
typedef struct _GtkWidget GtkWidget;

// Fonction pour callback.c
void afficher_entraineurs(GtkWidget *treeview);

#endif // ENTRAINEUR_H_INCLUDED
