#include "entraineur.h"
#include <stdlib.h>
#include <string.h>

// Ajouter un entraîneur au fichier
int ajouter_entraineur(char *filename, Entraineur e) {
    FILE *f = fopen(filename, "a");
    if (f != NULL) {
        fprintf(f, "%s|%s|%s|%s|%s|%s|%s|%s|%s|%d\n",
                e.id, e.nom, e.email, e.telephone, e.sexe,
                e.specialite, e.disponibilite, e.jours, e.contrat, e.heures_semaine);
        fclose(f);
        return 1; // Succès
    }
    return 0; // Échec
}

// Modifier un entraîneur existant
int modifier_entraineur(char *filename, char *id, Entraineur nouv) {
    FILE *f = fopen(filename, "r");
    FILE *temp = fopen("temp.txt", "w");
    int modifie = 0;
    
    if (f != NULL && temp != NULL) {
        char ligne[500];
        while (fgets(ligne, sizeof(ligne), f)) {
            char current_id[MAX_ID];
            sscanf(ligne, "%[^|]", current_id);
            
            if (strcmp(current_id, id) == 0) {
                // Écrire les nouvelles données
                fprintf(temp, "%s|%s|%s|%s|%s|%s|%s|%s|%s|%d\n",
                        nouv.id, nouv.nom, nouv.email, nouv.telephone, nouv.sexe,
                        nouv.specialite, nouv.disponibilite, nouv.jours, nouv.contrat, nouv.heures_semaine);
                modifie = 1;
            } else {
                // Recopier la ligne inchangée
                fputs(ligne, temp);
            }
        }
        fclose(f);
        fclose(temp);
        
        // Remplacer l'ancien fichier par le nouveau
        if (modifie) {
            remove(filename);
            rename("temp.txt", filename);
        } else {
            remove("temp.txt");
        }
    }
    
    return modifie;
}

// Supprimer un entraîneur
int supprimer_entraineur(char *filename, char *id) {
    FILE *f = fopen(filename, "r");
    FILE *temp = fopen("temp.txt", "w");
    int supprime = 0;
    
    if (f != NULL && temp != NULL) {
        char ligne[500];
        while (fgets(ligne, sizeof(ligne), f)) {
            char current_id[MAX_ID];
            sscanf(ligne, "%[^|]", current_id);
            
            if (strcmp(current_id, id) == 0) {
                supprime = 1; // Ne pas écrire cette ligne
            } else {
                fputs(ligne, temp);
            }
        }
        fclose(f);
        fclose(temp);
        
        // Remplacer l'ancien fichier par le nouveau
        if (supprime) {
            remove(filename);
            rename("temp.txt", filename);
        } else {
            remove("temp.txt");
        }
    }
    
    return supprime;
}

// Chercher un entraîneur par ID
Entraineur chercher_entraineur(char *filename, char *id) {
    FILE *f = fopen(filename, "r");
    Entraineur e;
    int trouve = 0;
    
    // Initialiser avec des valeurs par défaut
    memset(&e, 0, sizeof(Entraineur));
    strcpy(e.id, "-1"); // ID -1 signifie non trouvé
    
    if (f != NULL) {
        char ligne[500];
        while (fgets(ligne, sizeof(ligne), f) && !trouve) {
            char current_id[MAX_ID];
            char *token;
            
            // Extraire l'ID
            token = strtok(ligne, "|");
            if (token) {
                strcpy(current_id, token);
                if (strcmp(current_id, id) == 0) {
                    // ID trouvé, extraire toutes les données
                    strcpy(e.id, current_id);
                    
                    token = strtok(NULL, "|");
                    if (token) strcpy(e.nom, token);
                    
                    token = strtok(NULL, "|");
                    if (token) strcpy(e.email, token);
                    
                    token = strtok(NULL, "|");
                    if (token) strcpy(e.telephone, token);
                    
                    token = strtok(NULL, "|");
                    if (token) strcpy(e.sexe, token);
                    
                    token = strtok(NULL, "|");
                    if (token) strcpy(e.specialite, token);
                    
                    token = strtok(NULL, "|");
                    if (token) strcpy(e.disponibilite, token);
                    
                    token = strtok(NULL, "|");
                    if (token) strcpy(e.jours, token);
                    
                    token = strtok(NULL, "|");
                    if (token) strcpy(e.contrat, token);
                    
                    token = strtok(NULL, "|");
                    if (token) e.heures_semaine = atoi(token);
                    
                    trouve = 1;
                }
            }
        }
        fclose(f);
    }
    
    return e;
}

// Compter le nombre d'entraîneurs
int compter_entraineurs(char *filename) {
    FILE *f = fopen(filename, "r");
    int count = 0;
    
    if (f != NULL) {
        char ligne[500];
        while (fgets(ligne, sizeof(ligne), f)) {
            // Compter seulement les lignes non vides
            if (strlen(ligne) > 1) {
                count++;
            }
        }
        fclose(f);
    }
    
    return count;
}

// Afficher tous les entraîneurs dans la console (pour débogage)
void afficher_tous_entraineurs(char *filename) {
    FILE *f = fopen(filename, "r");
    
    if (f != NULL) {
        char ligne[500];
        int count = 0;
        
        printf("=== LISTE DES ENTRAÎNEURS (%s) ===\n", filename);
        
        while (fgets(ligne, sizeof(ligne), f)) {
            ligne[strcspn(ligne, "\n")] = '\0';
            
            if (strlen(ligne) > 0) {
                count++;
                
                char *tokens[10];
                char ligne_copie[500];
                strcpy(ligne_copie, ligne);
                
                char *token = strtok(ligne_copie, "|");
                int i = 0;
                
                while (token != NULL && i < 10) {
                    tokens[i++] = token;
                    token = strtok(NULL, "|");
                }
                
                if (i >= 6) {
                    printf("%d. ID: %s, Nom: %s\n", count, tokens[0], tokens[1]);
                    if (i >= 5) printf("   Email: %s, Tel: %s, Sexe: %s\n", 
                                      i>2?tokens[2]:"", i>3?tokens[3]:"", i>4?tokens[4]:"");
                }
            }
        }
        
        if (count == 0) {
            printf("Aucun entraîneur trouvé.\n");
        }
        
        fclose(f);
    } else {
        printf("Fichier %s non trouvé.\n", filename);
    }
}

// Fonction supplémentaire: vérifier si un ID existe
int id_entraineur_existe(char *filename, char *id) {
    Entraineur e = chercher_entraineur(filename, id);
    return (strcmp(e.id, "-1") != 0);
}
