#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "entraineur.h"

// Fonction pour tester toutes les opérations CRUD
void tester_fonctions_entraineur() {
    printf("=== TEST DES FONCTIONS ENTRAÎNEUR ===\n\n");
    
    // Créer quelques entraîneurs de test
  Entraineur e1, e2, e_modifie;
    
    // Initialiser e1
    strcpy(e1.id, "ENT001");
    strcpy(e1.nom, "Jean Dupont");
    strcpy(e1.email, "jean.dupont@email.com");
    strcpy(e1.telephone, "0612345678");
    strcpy(e1.sexe, "Homme");
    strcpy(e1.specialite, "Musculation");
    strcpy(e1.disponibilite, "Matin");
    strcpy(e1.jours, "Lun Mar Mer Jeu");
    strcpy(e1.contrat, "CDI");
    e1.heures_semaine = 35;
    
    // Initialiser e2
    strcpy(e2.id, "ENT002");
    strcpy(e2.nom, "Marie Martin");
    strcpy(e2.email, "marie.martin@email.com");
    strcpy(e2.telephone, "0698765432");
    strcpy(e2.sexe, "Femme");
    strcpy(e2.specialite, "Yoga");
    strcpy(e2.disponibilite, "Soir");
    strcpy(e2.jours, "Mar Jeu Sam");
    strcpy(e2.contrat, "CDD");
    e2.heures_semaine = 20;
    
    // Test 1: Ajouter des entraîneurs
    printf("1. AJOUT D'ENTRAÎNEURS:\n");
    if (ajouter_entraineur("entraineurs.txt", e1)) {
        printf("   ✓ Entraîneur %s ajouté avec succès\n", e1.id);
    } else {
        printf("   ✗ Échec d'ajout pour %s\n", e1.id);
    }
    
    if (ajouter_entraineur("entraineurs.txt", e2)) {
        printf("   ✓ Entraîneur %s ajouté avec succès\n", e2.id);
    } else {
        printf("   ✗ Échec d'ajout pour %s\n", e2.id);
    }
    
    // Test 2: Afficher tous les entraîneurs
    printf("\n2. AFFICHAGE DE TOUS LES ENTRAÎNEURS:\n");
    afficher_tous_entraineurs("entraineurs.txt");
    
    // Test 3: Rechercher un entraîneur
    printf("\n3. RECHERCHE D'ENTRAÎNEUR:\n");
    Entraineur e_recherche = chercher_entraineur("entraineurs.txt", "ENT001");
    if (strcmp(e_recherche.id, "-1") != 0) {
        printf("   ✓ Entraîneur trouvé: %s - %s\n", e_recherche.id, e_recherche.nom);
    } else {
        printf("   ✗ Entraîneur non trouvé\n");
    }
    
    // Test 4: Modifier un entraîneur
    printf("\n4. MODIFICATION D'ENTRAÎNEUR:\n");
    // Créer une version modifiée de e1
    strcpy(e_modifie.id, "ENT001");
    strcpy(e_modifie.nom, "Jean Dupont MODIFIE");
    strcpy(e_modifie.email, "jean.dupont.modifie@email.com");
    strcpy(e_modifie.telephone, "0699999999");
    strcpy(e_modifie.sexe, "Homme");
    strcpy(e_modifie.specialite, "Musculation et Cardio");
    strcpy(e_modifie.disponibilite, "Toute la journée");
    strcpy(e_modifie.jours, "Lun Mar Mer Jeu Ven");
    strcpy(e_modifie.contrat, "CDI");
    e_modifie.heures_semaine = 40;
    
    if (modifier_entraineur("entraineurs.txt", "ENT001", e_modifie)) {
        printf("   ✓ Entraîneur modifié avec succès\n");
    } else {
        printf("   ✗ Échec de modification\n");
    }
    
    // Vérifier la modification
    e_recherche = chercher_entraineur("entraineurs.txt", "ENT001");
    printf("   Vérification: %s - %s - %s\n", 
           e_recherche.id, e_recherche.nom, e_recherche.telephone);
    
    // Test 5: Supprimer un entraîneur
    printf("\n5. SUPPRESSION D'ENTRAÎNEUR:\n");
    if (supprimer_entraineur("entraineurs.txt", "ENT002")) {
        printf("   ✓ Entraîneur supprimé avec succès\n");
    } else {
        printf("   ✗ Échec de suppression\n");
    }
    
    // Test 6: Compter les entraîneurs
    printf("\n6. NOMBRE D'ENTRAÎNEURS:\n");
    int nombre = compter_entraineurs("entraineurs.txt");
    printf("   Nombre d'entraîneurs dans le fichier: %d\n", nombre);
    
    // Test 7: Afficher final
    printf("\n7. ÉTAT FINAL:\n");
    afficher_tous_entraineurs("entraineurs.txt");
    
    printf("\n=== FIN DES TESTS ===\n");
}

// Menu interactif simple
void menu_interactif() {
    int choix;
    char buffer[100];
    
    do {
        printf("\n=== MENU GESTION ENTRAÎNEURS ===\n");
        printf("1. Ajouter un entraîneur\n");
        printf("2. Modifier un entraîneur\n");
        printf("3. Supprimer un entraîneur\n");
        printf("4. Rechercher un entraîneur\n");
        printf("5. Afficher tous les entraîneurs\n");
        printf("6. Compter les entraîneurs\n");
        printf("7. Lancer les tests automatiques\n");
        printf("0. Quitter\n");
        printf("Choix: ");
        
        fgets(buffer, sizeof(buffer), stdin);
        sscanf(buffer, "%d", &choix);
        
        switch (choix) {
            case 1: {
                Entraineur e;
                printf("\n--- AJOUTER UN ENTRAÎNEUR ---\n");
                
                printf("ID: "); fgets(e.id, MAX_ID, stdin); e.id[strcspn(e.id, "\n")] = '\0';
                printf("Nom/Prénom: "); fgets(e.nom, MAX_NOM, stdin); e.nom[strcspn(e.nom, "\n")] = '\0';
                printf("Email: "); fgets(e.email, MAX_EMAIL, stdin); e.email[strcspn(e.email, "\n")] = '\0';
                printf("Téléphone: "); fgets(e.telephone, MAX_TEL, stdin); e.telephone[strcspn(e.telephone, "\n")] = '\0';
                printf("Sexe (Homme/Femme): "); fgets(e.sexe, MAX_SEXE, stdin); e.sexe[strcspn(e.sexe, "\n")] = '\0';
                printf("Spécialité: "); fgets(e.specialite, MAX_SPECIALITE, stdin); e.specialite[strcspn(e.specialite, "\n")] = '\0';
                printf("Disponibilité: "); fgets(e.disponibilite, MAX_DISPONIBILITE, stdin); e.disponibilite[strcspn(e.disponibilite, "\n")] = '\0';
                printf("Jours de travail: "); fgets(e.jours, MAX_JOURS, stdin); e.jours[strcspn(e.jours, "\n")] = '\0';
                printf("Type de contrat: "); fgets(e.contrat, MAX_CONTRAT, stdin); e.contrat[strcspn(e.contrat, "\n")] = '\0';
                printf("Heures par semaine: "); fgets(buffer, sizeof(buffer), stdin); sscanf(buffer, "%d", &e.heures_semaine);
                
                if (ajouter_entraineur("entraineurs.txt", e)) {
                    printf("✓ Entraîneur ajouté avec succès!\n");
                } else {
                    printf("✗ Échec d'ajout.\n");
                }
                break;
            }
            
            case 4: {
                char id[MAX_ID];
                printf("\n--- RECHERCHER UN ENTRAÎNEUR ---\n");
                printf("ID à rechercher: ");
                fgets(id, MAX_ID, stdin);
                id[strcspn(id, "\n")] = '\0';
                
                Entraineur e = chercher_entraineur("entraineurs.txt", id);
                if (strcmp(e.id, "-1") != 0) {
                    printf("\n✓ Entraîneur trouvé:\n");
                    printf("  ID: %s\n", e.id);
                    printf("  Nom: %s\n", e.nom);
                    printf("  Email: %s\n", e.email);
                    printf("  Téléphone: %s\n", e.telephone);
                    printf("  Sexe: %s\n", e.sexe);
                    printf("  Spécialité: %s\n", e.specialite);
                    printf("  Disponibilité: %s\n", e.disponibilite);
                    printf("  Jours: %s\n", e.jours);
                    printf("  Contrat: %s\n", e.contrat);
                    printf("  Heures/semaine: %d\n", e.heures_semaine);
                } else {
                    printf("\n✗ Aucun entraîneur trouvé avec l'ID: %s\n", id);
                }
                break;
            }
            
            case 5:
                printf("\n--- LISTE DES ENTRAÎNEURS ---\n");
                afficher_tous_entraineurs("entraineurs.txt");
                break;
                
            case 6:
                printf("\n--- NOMBRE D'ENTRAÎNEURS ---\n");
                printf("Nombre d'entraîneurs: %d\n", compter_entraineurs("entraineurs.txt"));
                break;
                
            case 7:
                tester_fonctions_entraineur();
                break;
                
            case 0:
                printf("Au revoir!\n");
                break;
                
            default:
                printf("Choix invalide!\n");
        }
        
    } while (choix != 0);
}

int main() {
    printf("=== APPLICATION DE GESTION DES ENTRAÎNEURS ===\n");
    
    // Vous pouvez choisir l'une des options suivantes:
    
    // Option 1: Lancer les tests automatiques
    tester_fonctions_entraineur();
    
    // Option 2: Lancer le menu interactif (décommentez la ligne suivante)
    // menu_interactif();
    
    return 0;
}
