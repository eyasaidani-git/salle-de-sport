#include <gtk/gtk.h>


void
on_button_precedent_clicked  (GtkButton       *button,
                                        gpointer         user_data);
void
on_button_suivant_clicked  (GtkButton       *button,
                                        gpointer         user_data);


void
on_treeview_membres_row_activated      (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_ajoutermembre_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_modifiermembre_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_supprimermembre_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_checkbutton_ouiassurance_toggled    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_pasencoreassurance_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_hommemembre_toggled     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_femmemembre_toggled     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_validermembre_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_fermermembre_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton_expiremembre_toggled    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_activemembre_toggled    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_recherchermembre_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_spinbutton_om19_changed             (GtkEditable     *editable,
                                        gpointer         user_data);

void
on_treeview_entraineurs_row_activated  (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_radiobutton_hommeentraineur_toggled (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_combobox_om7_changed                (GtkComboBox     *combobox,
                                        gpointer         user_data);

void
on_radiobutton_matinentraineur_toggled (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_soirentraineur_toggled  (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_touteentraineur_toggled (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_mercredientraineur_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_lundientraineur_toggled (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_mardientraineur_toggled (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_jeudientraineur_toggled (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_vendredientraineur_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_samedientraineur_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_dimancheentraineur_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_combobox_om18_changed               (GtkComboBox     *combobox,
                                        gpointer         user_data);

void
on_button_ajouterentraineur_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_modifierentraineur_clicked   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_supprimerentraineur_clicked  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_validerentraineur_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_fermerentraineur_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_rechercherentraineur_clicked (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton_femmeentraineur_toggled (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_treeview_cours_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_checkbutton_publiccours_toggled     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_privecours_toggled      (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_debutantecours_toggled  (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_intermediairecours_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_avancecours_toggled     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_ajoutercours_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_modifiercours_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_supprimercours_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_validercours_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_fermercours_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_recherchercours_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview_equipement_row_activated   (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_chercher_g_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton_sfitnesse_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_smusculation_toggled    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_sdance__toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_consommable_toggled     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ajouter_g_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_modifier_g_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_supprimer_g_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_valider_g_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_fermer_g_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton_sboxe_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_treeview_centre_row_activated       (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_recherche_centre_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_etat_actif_centre_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ajouter_centre_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_modifier_centre_enter               (GtkButton       *button,
                                        gpointer         user_data);

void
on_supprimer_centre_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_valider_centre_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_fermer_centre_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_etat_inactif_centre_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

//void
//on_treeview_stat_centre_row_activated  (GtkTreeView     *treeview,
                                        //GtkTreePath     *path,
                                        //GtkTreeViewColumn *column,
                                        //gpointer         user_data);

//void
//on_afficher_statistiques_centre_clicked
                                        //(GtkButton       *button,
                                        //gpointer         user_data);

//void
//on_radiobutton_mixtecoursprv_toggled   (GtkToggleButton *togglebutton,
                                        //gpointer         user_data);

void
on_radiobutton_unisexcoursprv_toggled  (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_fermercoursprv_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_validercoursprv_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_checkbutton_lundicoachprv_toggled   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_mardicoachprv_toggled   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_mercredicoachprv_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_jeudicoachprv_toggled   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_vendredicoachprv_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_samedicoachprv_toggled  (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_dimanchecoachprv_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_touscoachprv_toggled    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_spinbutton20_change_value           (GtkSpinButton   *spinbutton,
                                        GtkScrollType    scroll,
                                        gpointer         user_data);

void
on_spinbutton21_change_value           (GtkSpinButton   *spinbutton,
                                        GtkScrollType    scroll,
                                        gpointer         user_data);

void
on_spinbutton1_change_value            (GtkSpinButton   *spinbutton,
                                        GtkScrollType    scroll,
                                        gpointer         user_data);

void
on_combobox_coursportif2_changed       (GtkComboBox     *combobox,
                                        gpointer         user_data);

void
on_combobox_localisation2_changed      (GtkComboBox     *combobox,
                                        gpointer         user_data);

void
on_valider2_oumaima_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_inscrire_centre_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_S_musculation_r_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_S_fitnesse_r_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_S_dance_r_toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_S_box_r_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_cours_puplique_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_coaching_prive_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_reserverequipement_clicked   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_annulerreservation_clicked   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_seconnecteradmin_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_seconnecterentraineur_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_seconnectermembre_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_entraineur_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_admin_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_membre_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ajouterequipement_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_modifierequipement_clicked   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_supprimerequipement_clicked  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_validerequipement_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_fermerequipement_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_rechercherequipement_clicked (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton_sfitnessereserver_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_smusculationreserver_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_sdancereserver_toggled  (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_sboxreeserver_toggled   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_sinscrireauncours_clicked    (GtkButton       *button,
                                        gpointer         user_data);
