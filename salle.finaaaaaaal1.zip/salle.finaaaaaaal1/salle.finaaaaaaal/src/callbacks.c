#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"

char g_sexe_entraineur[10] = "";
char g_dispo_entraineur[30] = ""; /* Matin / Soir / Toute la journee */
char g_jours_entraineur[100] = ""; /* "Lundi,Mardi,..." */
int  g_selected_id_entraineur = -1;

/* ============ GLOBALS COURS ============ */
char g_niveau_cours[30] = ""; /* Debutant / Intermediaire / Avance */
char g_type_cours[30] = "";   /* Publique / Prive */
int  g_selected_id_cours = -1;

/* ============ GLOBALS EQUIPEMENT ============ */
char g_salle_type[30] = ""; /* S.fitnesse / S.musculation / S.danse / S.boxe */
int  g_consommable = 0;     /* 0/1 */
int  g_selected_id_equipement = -1;

/* ============ GLOBALS CENTRE ============ */
char g_etat_centre[15] = ""; /* Actif / Inactif */
int  g_selected_id_centre = -1;

void append_day(char *jours, const char *day, int active)
{
    if (!jours || !day) return;

    if (active)
    {
        if (strstr(jours, day) == NULL)
        {
            if (strlen(jours) > 0) strcat(jours, ",");
            strcat(jours, day);
        }
    }
    else
    {
        /* enlever day de la chaine */
        char copy[120] = "";
        strcpy(copy, jours);

        jours[0] = '\0';

        char *token = strtok(copy, ",");
        while (token)
        {
            if (strcmp(token, day) != 0)
            {
                if (strlen(jours) > 0) strcat(jours, ",");
                strcat(jours, token);
            }
            token = strtok(NULL, ",");
        }
    }
}

/* ================== GLOBALS (pas static) ================== */
char g_sexe_membre[10] = "";           /* "Homme" ou "Femme" */
char g_assurance_membre[20] = "";      /* "Oui" ou "Pas encore" */
char g_etat_membre[10] = "";           /* "Active" ou "Expire" */
int  g_selected_id_membre = -1;        /* ID sélectionné dans treeview */

/* ================== OUTILS (pas static) ================== */

void show_msg(GtkWidget *parent, GtkMessageType type, const char *txt)
{
    GtkWidget *d = gtk_message_dialog_new(GTK_WINDOW(parent),
                                         GTK_DIALOG_MODAL,
                                         type,
                                         GTK_BUTTONS_OK,
                                         "%s", txt);
    gtk_dialog_run(GTK_DIALOG(d));
    gtk_widget_destroy(d);
}

/* phone : "12 345 678" => 2 chiffres + espace + 3 + espace + 3 */
int check_phone_format(const char *tel)
{
    if (!tel) return 0;
    if ((int)strlen(tel) != 10) return 0;
    if (tel[2] != ' ' || tel[6] != ' ') return 0;
    for (int i = 0; i < 10; i++)
    {
        if (i == 2 || i == 6) continue;
        if (!isdigit((unsigned char)tel[i])) return 0;
    }
    return 1;
}

/* email : local + "@gmail.com" */
int check_gmail_format(const char *email)
{
    if (!email) return 0;
    const char *suffix = "@gmail.com";
    int le = strlen(email);
    int ls = strlen(suffix);
    if (le <= ls) return 0;
    if (strcmp(email + (le - ls), suffix) != 0) return 0;

    /* vérifier local-part (avant @) */
    for (int i = 0; i < le - ls; i++)
    {
        char c = email[i];
        if (!(isalnum((unsigned char)c) || c=='.' || c=='_' )) return 0;
    }
    return 1;
}

int is_valid_date(int j, int m, int a)
{
    if (a < 2025) return 0;
    if (m < 1 || m > 12) return 0;
    if (j < 1 || j > 31) return 0;
    return 1;
}

/* retourne "Expire" si date_inscrit + 30j < aujourd'hui, sinon "Active" */
void calc_etat_abonnement_30j(int j, int m, int a, char *out)
{
    time_t now = time(NULL);
    struct tm t0 = {0};
    t0.tm_mday = j;
    t0.tm_mon  = m - 1;
    t0.tm_year = a - 1900;
    time_t inscrit = mktime(&t0);
    time_t fin = inscrit + (30 * 24 * 3600);

    if (difftime(now, fin) > 0) strcpy(out, "Expire");
    else strcpy(out, "Active");
}

/* Génération ID auto: max(id)+1 depuis membres.txt */
int next_id_from_file(const char *filename)
{
    FILE *f = fopen(filename, "r");
    if (!f) return 1;

    int maxid = 0;
    char line[1024];
    while (fgets(line, sizeof(line), f))
    {
        int id = 0;
        /* format: id|... */
        sscanf(line, "%d|", &id);
        if (id > maxid) maxid = id;
    }
    fclose(f);
    return maxid + 1;
}

/* ================== TREEVIEW MEMBRES ==================
   Colonnes: ID, Nom, Prenom, Tel, Email, Age, Sexe, Maladie, Abonnement, Date, Etat, Centre, Assurance, Proches
*/
void refresh_treeview_membres(GtkWidget *treeview)
{
    GtkListStore *store;
    GtkTreeIter iter;

    store = gtk_list_store_new(14,
                               G_TYPE_INT,    /* id */
                               G_TYPE_STRING, /* nom */
                               G_TYPE_STRING, /* prenom */
                               G_TYPE_STRING, /* tel */
                               G_TYPE_STRING, /* email */
                               G_TYPE_INT,    /* age */
                               G_TYPE_STRING, /* sexe */
                               G_TYPE_STRING, /* maladie */
                               G_TYPE_STRING, /* abonnement */
                               G_TYPE_STRING, /* date */
                               G_TYPE_STRING, /* etat */
                               G_TYPE_STRING, /* centre */
                               G_TYPE_STRING, /* assurance */
                               G_TYPE_INT);   /* proches */

    FILE *f = fopen("membres.txt", "r");
    if (f)
    {
        char line[2048];
        while (fgets(line, sizeof(line), f))
        {
            int id, age, proches;
            char nom[100], prenom[100], tel[50], email[120], sexe[20], maladie[120];
            char abonnement[120], date[40], etat[20], centre[120], assurance[30];

            /* IMPORTANT: même format que celui utilisé à l'ajout */
            if (sscanf(line,
                       "%d|%99[^|]|%99[^|]|%49[^|]|%119[^|]|%d|%19[^|]|%119[^|]|%119[^|]|%39[^|]|%19[^|]|%119[^|]|%29[^|]|%d",
                       &id, nom, prenom, tel, email, &age, sexe, maladie, abonnement, date, etat, centre, assurance, &proches) == 14)
            {
                gtk_list_store_append(store, &iter);
                gtk_list_store_set(store, &iter,
                                   0, id,
                                   1, nom,
                                   2, prenom,
                                   3, tel,
                                   4, email,
                                   5, age,
                                   6, sexe,
                                   7, maladie,
                                   8, abonnement,
                                   9, date,
                                   10, etat,
                                   11, centre,
                                   12, assurance,
                                   13, proches,
                                   -1);
            }
        }
        fclose(f);
    }

    gtk_tree_view_set_model(GTK_TREE_VIEW(treeview), GTK_TREE_MODEL(store));
    g_object_unref(store);
}

/* créer colonnes si jamais tu ne les as pas créées dans Glade */
void init_treeview_membres(GtkWidget *treeview)
{
    GtkCellRenderer *renderer;
    GtkTreeViewColumn *col;

    if (gtk_tree_view_get_n_columns(GTK_TREE_VIEW(treeview)) > 0) return;

    renderer = gtk_cell_renderer_text_new();
    col = gtk_tree_view_column_new_with_attributes("ID", renderer, "text", 0, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), col);

    renderer = gtk_cell_renderer_text_new();
    col = gtk_tree_view_column_new_with_attributes("Nom", renderer, "text", 1, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), col);

    renderer = gtk_cell_renderer_text_new();
    col = gtk_tree_view_column_new_with_attributes("Prenom", renderer, "text", 2, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), col);

    renderer = gtk_cell_renderer_text_new();
    col = gtk_tree_view_column_new_with_attributes("Tel", renderer, "text", 3, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), col);

    renderer = gtk_cell_renderer_text_new();
    col = gtk_tree_view_column_new_with_attributes("Email", renderer, "text", 4, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), col);
     renderer = gtk_cell_renderer_text_new();
    col = gtk_tree_view_column_new_with_attributes("Age", renderer, "text", 5, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), col);
    renderer = gtk_cell_renderer_text_new();
    col = gtk_tree_view_column_new_with_attributes("Sexe", renderer, "text", 6, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), col);
    renderer = gtk_cell_renderer_text_new();
    col = gtk_tree_view_column_new_with_attributes("Maladie", renderer, "text", 7, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), col);
    renderer = gtk_cell_renderer_text_new();
    col = gtk_tree_view_column_new_with_attributes("Abonnement", renderer, "text", 8, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), col);
    renderer = gtk_cell_renderer_text_new();
    col = gtk_tree_view_column_new_with_attributes("Inscrit le ", renderer, "text", 9, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), col);
    renderer = gtk_cell_renderer_text_new();
    col = gtk_tree_view_column_new_with_attributes("Etat d'abonnement", renderer, "text", 10, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), col);
    renderer = gtk_cell_renderer_text_new();
    col = gtk_tree_view_column_new_with_attributes("Centre sportif", renderer, "text", 11, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), col);
    renderer = gtk_cell_renderer_text_new();
    col = gtk_tree_view_column_new_with_attributes("Assurance payee", renderer, "text", 12, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), col);
    renderer = gtk_cell_renderer_text_new();
    col = gtk_tree_view_column_new_with_attributes("Proches", renderer, "text", 13, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), col);


void init_treeview_entraineurs(GtkWidget *treeview)
{
    if (gtk_tree_view_get_n_columns(GTK_TREE_VIEW(treeview)) > 0) return;

    GtkCellRenderer *r = gtk_cell_renderer_text_new();
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview),
        gtk_tree_view_column_new_with_attributes("ID", r, "text", 0, NULL));

    r = gtk_cell_renderer_text_new();
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview),
        gtk_tree_view_column_new_with_attributes("Nom", r, "text", 1, NULL));

    r = gtk_cell_renderer_text_new();
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview),
        gtk_tree_view_column_new_with_attributes("Prenom", r, "text", 2, NULL));

    r = gtk_cell_renderer_text_new();
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview),
        gtk_tree_view_column_new_with_attributes("Tel", r, "text", 3, NULL));

    r = gtk_cell_renderer_text_new();
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview),
        gtk_tree_view_column_new_with_attributes("Email", r, "text", 4, NULL));

    r = gtk_cell_renderer_text_new();
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview),
        gtk_tree_view_column_new_with_attributes("Sexe", r, "text", 5, NULL));

    r = gtk_cell_renderer_text_new();
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview),
        gtk_tree_view_column_new_with_attributes("Specialite", r, "text", 6, NULL));

    r = gtk_cell_renderer_text_new();
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview),
        gtk_tree_view_column_new_with_attributes("Dispo", r, "text", 7, NULL));

    r = gtk_cell_renderer_text_new();
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview),
        gtk_tree_view_column_new_with_attributes("Jours", r, "text", 8, NULL));

    r = gtk_cell_renderer_text_new();
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview),
        gtk_tree_view_column_new_with_attributes("Contrat", r, "text", 9, NULL));

    r = gtk_cell_renderer_text_new();
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview),
        gtk_tree_view_column_new_with_attributes("Heures/S", r, "text", 10, NULL));

    r = gtk_cell_renderer_text_new();
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview),
        gtk_tree_view_column_new_with_attributes("Cout", r, "text", 11, NULL));
}

void refresh_treeview_entraineurs(GtkWidget *treeview)
{
    GtkListStore *store = gtk_list_store_new(12,
        G_TYPE_INT, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,
        G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,
        G_TYPE_INT, G_TYPE_STRING);

    FILE *f = fopen("entraineurs.txt", "r");
    if (f)
    {
        char line[2048];
        while (fgets(line, sizeof(line), f))
        {
            int id, heures;
            char nom[100], prenom[100], tel[50], email[120], sexe[20];
            char spec[60], dispo[40], jours[120], contrat[40], cout[60];

            if (sscanf(line,
                "%d|%99[^|]|%99[^|]|%49[^|]|%119[^|]|%19[^|]|%59[^|]|%39[^|]|%119[^|]|%39[^|]|%d|%59[^\n]",
                &id, nom, prenom, tel, email, sexe, spec, dispo, jours, contrat, &heures, cout) == 12)
            {
                GtkTreeIter it;
                gtk_list_store_append(store, &it);
                gtk_list_store_set(store, &it,
                    0,id, 1,nom, 2,prenom, 3,tel, 4,email, 5,sexe,
                    6,spec, 7,dispo, 8,jours, 9,contrat, 10,heures, 11,cout, -1);
            }
        }
        fclose(f);
    }

    gtk_tree_view_set_model(GTK_TREE_VIEW(treeview), GTK_TREE_MODEL(store));
    g_object_unref(store);
}

void init_treeview_centre(GtkWidget *treeview)
{
    if (gtk_tree_view_get_n_columns(GTK_TREE_VIEW(treeview)) > 0) return;
    GtkCellRenderer *r = gtk_cell_renderer_text_new();
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), gtk_tree_view_column_new_with_attributes("ID", r, "text", 0, NULL));
    r = gtk_cell_renderer_text_new();
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), gtk_tree_view_column_new_with_attributes("Nom", r, "text", 1, NULL));
    r = gtk_cell_renderer_text_new();
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), gtk_tree_view_column_new_with_attributes("Adresse", r, "text", 2, NULL));
    r = gtk_cell_renderer_text_new();
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), gtk_tree_view_column_new_with_attributes("Coaches", r, "text", 3, NULL));
    r = gtk_cell_renderer_text_new();
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), gtk_tree_view_column_new_with_attributes("Membres", r, "text", 4, NULL));
    r = gtk_cell_renderer_text_new();
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), gtk_tree_view_column_new_with_attributes("Salles", r, "text", 5, NULL));
    r = gtk_cell_renderer_text_new();
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), gtk_tree_view_column_new_with_attributes("Capacite", r, "text", 6, NULL));
    r = gtk_cell_renderer_text_new();
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), gtk_tree_view_column_new_with_attributes("Etat", r, "text", 7, NULL));
}

void refresh_treeview_centre(GtkWidget *treeview)
{
    GtkListStore *store = gtk_list_store_new(8,
        G_TYPE_INT, G_TYPE_STRING, G_TYPE_STRING,
        G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT,
        G_TYPE_STRING);

    FILE *f=fopen("centres.txt","r");
    if(f)
    {
        char line[2048];
        while(fgets(line,sizeof(line),f))
        {
            int id, coaches, membres, salles, capacite;
            char nom[120], adresse[80], etat[20];
            if(sscanf(line,"%d|%119[^|]|%79[^|]|%d|%d|%d|%d|%19[^\n]",
                      &id,nom,adresse,&coaches,&membres,&salles,&capacite,etat)==8)
            {
                GtkTreeIter it;
                gtk_list_store_append(store,&it);
                gtk_list_store_set(store,&it,0,id,1,nom,2,adresse,3,coaches,4,membres,5,salles,6,capacite,7,etat,-1);
            }
        }
        fclose(f);
    }
    gtk_tree_view_set_model(GTK_TREE_VIEW(treeview),GTK_TREE_MODEL(store));
    g_object_unref(store);
}

void init_treeview_cours(GtkWidget *treeview)
{
    if (gtk_tree_view_get_n_columns(GTK_TREE_VIEW(treeview)) > 0) return;

    GtkCellRenderer *r = gtk_cell_renderer_text_new();
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview),
        gtk_tree_view_column_new_with_attributes("ID", r, "text", 0, NULL));
    r = gtk_cell_renderer_text_new();
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview),
        gtk_tree_view_column_new_with_attributes("Cours", r, "text", 1, NULL));
    r = gtk_cell_renderer_text_new();
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview),
        gtk_tree_view_column_new_with_attributes("Entraineur", r, "text", 2, NULL));
    r = gtk_cell_renderer_text_new();
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview),
        gtk_tree_view_column_new_with_attributes("Centre", r, "text", 3, NULL));
    r = gtk_cell_renderer_text_new();
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview),
        gtk_tree_view_column_new_with_attributes("Heure", r, "text", 4, NULL));
    r = gtk_cell_renderer_text_new();
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview),
        gtk_tree_view_column_new_with_attributes("Jour", r, "text", 5, NULL));
    r = gtk_cell_renderer_text_new();
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview),
        gtk_tree_view_column_new_with_attributes("Duree", r, "text", 6, NULL));
    r = gtk_cell_renderer_text_new();
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview),
        gtk_tree_view_column_new_with_attributes("Date", r, "text", 7, NULL));
    r = gtk_cell_renderer_text_new();
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview),
        gtk_tree_view_column_new_with_attributes("Niveau", r, "text", 8, NULL));
    r = gtk_cell_renderer_text_new();
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview),
        gtk_tree_view_column_new_with_attributes("Type", r, "text", 9, NULL));
}

void init_treeview_equipement(GtkWidget *treeview)
{
    if (gtk_tree_view_get_n_columns(GTK_TREE_VIEW(treeview)) > 0) return;
    GtkCellRenderer *r = gtk_cell_renderer_text_new();
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), gtk_tree_view_column_new_with_attributes("ID", r, "text", 0, NULL));
    r = gtk_cell_renderer_text_new();
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), gtk_tree_view_column_new_with_attributes("Salle", r, "text", 1, NULL));
    r = gtk_cell_renderer_text_new();
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), gtk_tree_view_column_new_with_attributes("Type", r, "text", 2, NULL));
    r = gtk_cell_renderer_text_new();
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), gtk_tree_view_column_new_with_attributes("Nom", r, "text", 3, NULL));
    r = gtk_cell_renderer_text_new();
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), gtk_tree_view_column_new_with_attributes("Recent", r, "text", 4, NULL));
    r = gtk_cell_renderer_text_new();
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), gtk_tree_view_column_new_with_attributes("Date", r, "text", 5, NULL));
    r = gtk_cell_renderer_text_new();
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), gtk_tree_view_column_new_with_attributes("Quantite", r, "text", 6, NULL));
    r = gtk_cell_renderer_text_new();
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), gtk_tree_view_column_new_with_attributes("Consommable", r, "text", 7, NULL));
}

void refresh_treeview_equipement(GtkWidget *treeview)
{
    GtkListStore *store = gtk_list_store_new(8,
        G_TYPE_INT, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,
        G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT, G_TYPE_STRING);

    FILE *f = fopen("equipements.txt","r");
    if (f)
    {
        char line[2048];
        while (fgets(line,sizeof(line),f))
        {
            int id, q;
            char salle[60], type[40], nom[120], recent[120], date[40], cons[20];

            if (sscanf(line,"%d|%59[^|]|%39[^|]|%119[^|]|%119[^|]|%39[^|]|%d|%19[^\n]",
                       &id, salle, type, nom, recent, date, &q, cons) == 8)
            {
                GtkTreeIter it;
                gtk_list_store_append(store,&it);
                gtk_list_store_set(store,&it,0,id,1,salle,2,type,3,nom,4,recent,5,date,6,q,7,cons,-1);
            }
        }
        fclose(f);
    }

    gtk_tree_view_set_model(GTK_TREE_VIEW(treeview), GTK_TREE_MODEL(store));
    g_object_unref(store);
}
void refresh_treeview_cours(GtkWidget *treeview)
{
    GtkListStore *store = gtk_list_store_new(10,
        G_TYPE_INT, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,
        G_TYPE_INT, G_TYPE_STRING, G_TYPE_INT, G_TYPE_STRING,
        G_TYPE_STRING, G_TYPE_STRING);

    FILE *f = fopen("cours.txt","r");
    if (f)
    {
        char line[2048];
        while (fgets(line,sizeof(line),f))
        {
            int id, heure, duree;
            char nomcours[60], ent[80], centre[120], jour[30], date[40], niveau[30], type[30];

            if (sscanf(line, "%d|%59[^|]|%79[^|]|%119[^|]|%d|%29[^|]|%d|%39[^|]|%29[^|]|%29[^\n]",
                       &id, nomcours, ent, centre, &heure, jour, &duree, date, niveau, type) == 10)
            {
                GtkTreeIter it;
                gtk_list_store_append(store,&it);
                gtk_list_store_set(store,&it,
                    0,id,1,nomcours,2,ent,3,centre,4,heure,5,jour,6,duree,7,date,8,niveau,9,type,-1);
            }
        }
        fclose(f);
    }
    gtk_tree_view_set_model(GTK_TREE_VIEW(treeview), GTK_TREE_MODEL(store));
    g_object_unref(store);
}

int is_int_str(const char *s)
{
    if (!s || !*s) return 0;
    for (int i=0; s[i]; i++) if (!isdigit((unsigned char)s[i])) return 0;
    return 1;
}

void
on_button_precedent_clicked  (GtkButton       *button,
{
    GtkWidget *nb = lookup_widget(GTK_WIDGET(button), "notebook_gestion");
    int p = gtk_notebook_get_current_page(GTK_NOTEBOOK(nb));
    if (p > 0) gtk_notebook_set_current_page(GTK_NOTEBOOK(nb), p-1);
}                                        gpointer         user_data)
void
on_button_suivant_clicked  (GtkButton       *button,
                                        gpointer         user_data)
{
    GtkWidget *nb = lookup_widget(GTK_WIDGET(button), "notebook_gestion");
    int p = gtk_notebook_get_current_page(GTK_NOTEBOOK(nb));
    int n = gtk_notebook_get_n_pages(GTK_NOTEBOOK(nb));
    if (p < n-1) gtk_notebook_set_current_page(GTK_NOTEBOOK(nb), p+1);
}

void
on_treeview_membres_row_activated      (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeModel *model;
    GtkTreeIter iter;

    model = gtk_tree_view_get_model(treeview);
    if (gtk_tree_model_get_iter(model, &iter, path))
    {
        int id, age, proches;
        char *nom, *prenom, *tel, *email, *sexe, *maladie, *abonnement, *date, *etat, *centre, *assurance;

        gtk_tree_model_get(model, &iter,
                           0, &id,
                           1, &nom,
                           2, &prenom,
                           3, &tel,
                           4, &email,
                           5, &age,
                           6, &sexe,
                           7, &maladie,
                           8, &abonnement,
                           9, &date,
                           10, &etat,
                           11, &centre,
                           12, &assurance,
                           13, &proches,
                           -1);

        g_selected_id_membre = id;

        /* Tu peux aussi remplir les champs ici si tu veux (entry/spin/combobox) */

        g_free(nom); g_free(prenom); g_free(tel); g_free(email);
        g_free(sexe); g_free(maladie); g_free(abonnement); g_free(date);
        g_free(etat); g_free(centre); g_free(assurance);
    }
}


void
on_button_ajoutermembre_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *w = lookup_widget(GTK_WIDGET(button), "window_gestion");

    GtkWidget *tree = lookup_widget(GTK_WIDGET(button), "treeview_membres");
    GtkWidget *enom = lookup_widget(GTK_WIDGET(button), "entry_nom_membre");
    GtkWidget *epr  = lookup_widget(GTK_WIDGET(button), "entry_prenom_membre");
    GtkWidget *etel = lookup_widget(GTK_WIDGET(button), "entry_tel_membre");
    GtkWidget *email= lookup_widget(GTK_WIDGET(button), "entry_email_membre");
    GtkWidget *emal = lookup_widget(GTK_WIDGET(button), "entry_maladie_membre");

    GtkWidget *sage = lookup_widget(GTK_WIDGET(button), "spin_age_membre");
    GtkWidget *sj   = lookup_widget(GTK_WIDGET(button), "spin_jour_inscrit_membre");
    GtkWidget *sm   = lookup_widget(GTK_WIDGET(button), "spin_mois_inscrit_membre");
    GtkWidget *sa   = lookup_widget(GTK_WIDGET(button), "spin_annee_inscrit_membre");
    GtkWidget *spro = lookup_widget(GTK_WIDGET(button), "spin_proches_membre");

    GtkWidget *cab  = lookup_widget(GTK_WIDGET(button), "combobox_abonnement_membre");
    GtkWidget *ccen = lookup_widget(GTK_WIDGET(button), "combobox_centre_membre");

    const char *nom = gtk_entry_get_text(GTK_ENTRY(enom));
    const char *prenom = gtk_entry_get_text(GTK_ENTRY(epr));
    const char *tel = gtk_entry_get_text(GTK_ENTRY(etel));
    const char *mail = gtk_entry_get_text(GTK_ENTRY(email));
    const char *maladie = gtk_entry_get_text(GTK_ENTRY(emal));

    int age = (int)gtk_spin_button_get_value(GTK_SPIN_BUTTON(sage));
    int j = (int)gtk_spin_button_get_value(GTK_SPIN_BUTTON(sj));
    int m = (int)gtk_spin_button_get_value(GTK_SPIN_BUTTON(sm));
    int a = (int)gtk_spin_button_get_value(GTK_SPIN_BUTTON(sa));
    int proches = (int)gtk_spin_button_get_value(GTK_SPIN_BUTTON(spro));

    char *abonnement = gtk_combo_box_text_get_active_text(GTK_COMBO_BOX_TEXT(cab));
    char *centre = gtk_combo_box_text_get_active_text(GTK_COMBO_BOX_TEXT(ccen));

    /* -------- contrôles -------- */
    if (!nom || strlen(nom)==0 || !prenom || strlen(prenom)==0)
    {
        show_msg(w, GTK_MESSAGE_ERROR, "Nom et Prenom obligatoires !");
        if (abonnement) g_free(abonnement);
        if (centre) g_free(centre);
        return;
    }
    if (strcmp(g_sexe_membre, "") == 0)
    {
        show_msg(w, GTK_MESSAGE_ERROR, "Choisir le sexe !");
        if (abonnement) g_free(abonnement);
        if (centre) g_free(centre);
        return;
    }
    if (!check_phone_format(tel))
    {
        show_msg(w, GTK_MESSAGE_ERROR, "Telephone invalide. Format: 12 345 678");
        if (abonnement) g_free(abonnement);
        if (centre) g_free(centre);
        return;
    }
    if (!check_gmail_format(mail))
    {
        show_msg(w, GTK_MESSAGE_ERROR, "Email invalide. Exemple: aaaa@gmail.com");
        if (abonnement) g_free(abonnement);
        if (centre) g_free(centre);
        return;
    }
    if (age < 10 || age > 90)
    {
        show_msg(w, GTK_MESSAGE_ERROR, "Age doit etre entre 10 et 90.");
        if (abonnement) g_free(abonnement);
        if (centre) g_free(centre);
        return;
    }
    if (!is_valid_date(j,m,a))
    {
        show_msg(w, GTK_MESSAGE_ERROR, "Date invalide (jour 1..31, mois 1..12, annee >= 2025)");
        if (abonnement) g_free(abonnement);
        if (centre) g_free(centre);
        return;
    }
    if (!abonnement || !centre)
    {
        show_msg(w, GTK_MESSAGE_ERROR, "Choisir Abonnement et Centre sportif !");
        if (abonnement) g_free(abonnement);
        if (centre) g_free(centre);
        return;
    }
    if (strcmp(g_assurance_membre,"") == 0)
    {
        show_msg(w, GTK_MESSAGE_ERROR, "Choisir assurance payee: Oui / Pas encore");
        if (abonnement) g_free(abonnement);
        if (centre) g_free(centre);
        return;
    }

    /* etat auto selon date + 30j */
    calc_etat_abonnement_30j(j,m,a, g_etat_membre);

    /* id auto */
    int id = next_id_from_file("membres.txt");

    char date_ins[40];
    sprintf(date_ins, "%02d/%02d/%04d", j,m,a);

    /* maladie peut etre vide => on garde vide */
    FILE *f = fopen("membres.txt", "a");
    if (!f)
    {
        show_msg(w, GTK_MESSAGE_ERROR, "Impossible d'ouvrir membres.txt");
        if (abonnement) g_free(abonnement);
        if (centre) g_free(centre);
        return;
    }

    fprintf(f, "%d|%s|%s|%s|%s|%d|%s|%s|%s|%s|%s|%s|%s|%d\n",
            id, nom, prenom, tel, mail, age, g_sexe_membre,
            (maladie?maladie:""), abonnement, date_ins, g_etat_membre,
            centre, g_assurance_membre, proches);
    fclose(f);

    init_treeview_membres(tree);
    refresh_treeview_membres(tree);

    show_msg(w, GTK_MESSAGE_INFO, "Membre ajoute avec succes.");

    if (abonnement) g_free(abonnement);
    if (centre) g_free(centre);
}


void
on_button_modifiermembre_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *w = lookup_widget(GTK_WIDGET(button), "window_gestion");
    GtkWidget *tree = lookup_widget(GTK_WIDGET(button), "treeview_membres");

    if (g_selected_id_membre < 0)
    {
        show_msg(w, GTK_MESSAGE_ERROR, "Selectionner un membre dans le tableau d'abord !");
        return;
    }

    /* on reprend les champs (même que ajouter) */
    GtkWidget *enom = lookup_widget(GTK_WIDGET(button), "entry_nom_membre");
    GtkWidget *epr  = lookup_widget(GTK_WIDGET(button), "entry_prenom_membre");
    GtkWidget *etel = lookup_widget(GTK_WIDGET(button), "entry_tel_membre");
    GtkWidget *email= lookup_widget(GTK_WIDGET(button), "entry_email_membre");
    GtkWidget *emal = lookup_widget(GTK_WIDGET(button), "entry_maladie_membre");

    GtkWidget *sage = lookup_widget(GTK_WIDGET(button), "spin_age_membre");
    GtkWidget *sj   = lookup_widget(GTK_WIDGET(button), "spin_jour_inscrit_membre");
    GtkWidget *sm   = lookup_widget(GTK_WIDGET(button), "spin_mois_inscrit_membre");
    GtkWidget *sa   = lookup_widget(GTK_WIDGET(button), "spin_annee_inscrit_membre");
    GtkWidget *spro = lookup_widget(GTK_WIDGET(button), "spin_proches_membre");

    GtkWidget *cab  = lookup_widget(GTK_WIDGET(button), "combobox_abonnement_membre");
    GtkWidget *ccen = lookup_widget(GTK_WIDGET(button), "combobox_centre_membre");

    const char *nom = gtk_entry_get_text(GTK_ENTRY(enom));
    const char *prenom = gtk_entry_get_text(GTK_ENTRY(epr));
    const char *tel = gtk_entry_get_text(GTK_ENTRY(etel));
    const char *mail = gtk_entry_get_text(GTK_ENTRY(email));
    const char *maladie = gtk_entry_get_text(GTK_ENTRY(emal));

    int age = (int)gtk_spin_button_get_value(GTK_SPIN_BUTTON(sage));
    int j = (int)gtk_spin_button_get_value(GTK_SPIN_BUTTON(sj));
    int m = (int)gtk_spin_button_get_value(GTK_SPIN_BUTTON(sm));
    int a = (int)gtk_spin_button_get_value(GTK_SPIN_BUTTON(sa));
    int proches = (int)gtk_spin_button_get_value(GTK_SPIN_BUTTON(spro));

    char *abonnement = gtk_combo_box_text_get_active_text(GTK_COMBO_BOX_TEXT(cab));
    char *centre = gtk_combo_box_text_get_active_text(GTK_COMBO_BOX_TEXT(ccen));

    if (!check_phone_format(tel) || !check_gmail_format(mail) || age<10 || age>90 || !is_valid_date(j,m,a))
    {
        show_msg(w, GTK_MESSAGE_ERROR, "Donnees invalides (tel/email/age/date) !");
        if (abonnement) g_free(abonnement);
        if (centre) g_free(centre);
        return;
    }
    if (!abonnement || !centre || strcmp(g_sexe_membre,"")==0 || strcmp(g_assurance_membre,"")==0)
    {
        show_msg(w, GTK_MESSAGE_ERROR, "Verifier sexe/assurance/abonnement/centre !");
        if (abonnement) g_free(abonnement);
        if (centre) g_free(centre);
        return;
    }

    calc_etat_abonnement_30j(j,m,a, g_etat_membre);

    char date_ins[40];
    sprintf(date_ins, "%02d/%02d/%04d", j,m,a);

    FILE *f = fopen("membres.txt", "r");
    FILE *tmp = fopen("membres_tmp.txt", "w");
    if (!f || !tmp)
    {
        if (f) fclose(f);
        if (tmp) fclose(tmp);
        show_msg(w, GTK_MESSAGE_ERROR, "Erreur fichier membres.txt");
        if (abonnement) g_free(abonnement);
        if (centre) g_free(centre);
        return;
    }

    char line[2048];
    while (fgets(line, sizeof(line), f))
    {
        int id=0;
        sscanf(line, "%d|", &id);

        if (id == g_selected_id_membre)
        {
            fprintf(tmp, "%d|%s|%s|%s|%s|%d|%s|%s|%s|%s|%s|%s|%s|%d\n",
                    id, nom, prenom, tel, mail, age, g_sexe_membre,
                    (maladie?maladie:""), abonnement, date_ins, g_etat_membre,
                    centre, g_assurance_membre, proches);
        }
        else
        {
            fputs(line, tmp);
        }
    }

    fclose(f);
    fclose(tmp);

    remove("membres.txt");
    rename("membres_tmp.txt", "membres.txt");

    init_treeview_membres(tree);
    refresh_treeview_membres(tree);

    show_msg(w, GTK_MESSAGE_INFO, "Membre modifie.");

    if (abonnement) g_free(abonnement);
    if (centre) g_free(centre);
}


void
on_button_supprimermembre_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *w = lookup_widget(GTK_WIDGET(button), "window_gestion");
    GtkWidget *tree = lookup_widget(GTK_WIDGET(button), "treeview_membres");

    if (g_selected_id_membre < 0)
    {
        show_msg(w, GTK_MESSAGE_ERROR, "Selectionner un membre dans le tableau d'abord !");
        return;
    }

    FILE *f = fopen("membres.txt", "r");
    FILE *tmp = fopen("membres_tmp.txt", "w");
    if (!f || !tmp)
    {
        if (f) fclose(f);
        if (tmp) fclose(tmp);
        show_msg(w, GTK_MESSAGE_ERROR, "Erreur fichier membres.txt");
        return;
    }

    char line[2048];
    while (fgets(line, sizeof(line), f))
    {
        int id=0;
        sscanf(line, "%d|", &id);
        if (id != g_selected_id_membre)
            fputs(line, tmp);
    }

    fclose(f);
    fclose(tmp);

    remove("membres.txt");
    rename("membres_tmp.txt", "membres.txt");

    g_selected_id_membre = -1;

    init_treeview_membres(tree);
    refresh_treeview_membres(tree);

    show_msg(w, GTK_MESSAGE_INFO, "Membre supprime.");
}


void
on_checkbutton_ouiassurance_toggled    (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
 if (gtk_toggle_button_get_active(togglebutton))
        strcpy(g_assurance_membre, "Oui");
}



void
on_checkbutton_pasencoreassurance_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
 if (gtk_toggle_button_get_active(togglebutton))
        strcpy(g_assurance_membre, "Pas encore");
}


void
on_radiobutton_hommemembre_toggled     (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
        strcpy(g_sexe_membre, "Homme");
}


void
on_radiobutton_femmemembre_toggled     (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
 if (gtk_toggle_button_get_active(togglebutton))
        strcpy(g_sexe_membre, "Femme");
}


void
on_button_validermembre_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{
 GtkWidget *w = lookup_widget(GTK_WIDGET(button), "window_gestion");
    show_msg(w, GTK_MESSAGE_INFO, "Validation OK.");
}


void
on_button_fermermembre_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *w = lookup_widget(GTK_WIDGET(button), "window_gestion");
    gtk_widget_hide(w);
}


void
on_radiobutton_expiremembre_toggled    (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
 if (gtk_toggle_button_get_active(togglebutton))
        strcpy(g_etat_membre, "Expire");
}


void
on_radiobutton_activemembre_toggled    (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
        strcpy(g_etat_membre, "Active");
}


void
on_button_recherchermembre_clicked     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *w = lookup_widget(GTK_WIDGET(button), "window_gestion");
    GtkWidget *tree = lookup_widget(GTK_WIDGET(button), "treeview_membres");
    GtkWidget *erech = lookup_widget(GTK_WIDGET(button), "entry_recherche_membre");

    const char *key = gtk_entry_get_text(GTK_ENTRY(erech));
    if (!key || strlen(key)==0)
    {
        init_treeview_membres(tree);
        refresh_treeview_membres(tree);
        return;
    }

    /* On affiche seulement les lignes qui matchent ID exact OU nom contient key */
    GtkListStore *store;
    GtkTreeIter iter;
    store = gtk_list_store_new(14,
                               G_TYPE_INT, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,
                               G_TYPE_INT, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,
                               G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT);

    FILE *f = fopen("membres.txt", "r");
    if (!f)
    {
        show_msg(w, GTK_MESSAGE_ERROR, "membres.txt introuvable");
        return;
    }

    int key_is_id = 1;
    for (int i=0; key[i]; i++) if (!isdigit((unsigned char)key[i])) { key_is_id = 0; break; }
    int idkey = key_is_id ? atoi(key) : -1;

    char line[2048];
    while (fgets(line, sizeof(line), f))
    {
        int id, age, proches;
        char nom[100], prenom[100], tel[50], email[120], sexe[20], maladie[120];
        char abonnement[120], date[40], etat[20], centre[120], assurance[30];

        if (sscanf(line,
                   "%d|%99[^|]|%99[^|]|%49[^|]|%119[^|]|%d|%19[^|]|%119[^|]|%119[^|]|%39[^|]|%19[^|]|%119[^|]|%29[^|]|%d",
                   &id, nom, prenom, tel, email, &age, sexe, maladie, abonnement, date, etat, centre, assurance, &proches) == 14)
        {
            int ok = 0;
            if (key_is_id && id == idkey) ok = 1;
            if (!key_is_id && strstr(nom, key) != NULL) ok = 1;

            if (ok)
            {
                gtk_list_store_append(store, &iter);
                gtk_list_store_set(store, &iter,
                                   0,id, 1,nom, 2,prenom, 3,tel, 4,email,
                                   5,age, 6,sexe, 7,maladie, 8,abonnement, 9,date,
                                   10,etat, 11,centre, 12,assurance, 13,proches, -1);
            }
        }
    }
    fclose(f);

    gtk_tree_view_set_model(GTK_TREE_VIEW(tree), GTK_TREE_MODEL(store));
    g_object_unref(store);
}





void
on_treeview_entraineurs_row_activated  (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
  GtkTreeIter iter;
    GtkTreeModel *model = gtk_tree_view_get_model(treeview);
    if (gtk_tree_model_get_iter(model, &iter, path))
    {
        int id;
        gtk_tree_model_get(model, &iter, 0, &id, -1);
        g_selected_id_entraineur = id;
    } 
}


void
on_radiobutton_hommeentraineur_toggled (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
  if (gtk_toggle_button_get_active(togglebutton)) strcpy(g_sexe_entraineur, "Homme");
}





void
on_radiobutton_matinentraineur_toggled (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
  if (gtk_toggle_button_get_active(togglebutton)) strcpy(g_dispo_entraineur, "Matin");
}


void
on_radiobutton_soirentraineur_toggled  (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
  if (gtk_toggle_button_get_active(togglebutton)) strcpy(g_dispo_entraineur, "Soir");
}


void
on_radiobutton_touteentraineur_toggled (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton)) strcpy(g_dispo_entraineur, "Toute la journee");
}


void
on_checkbutton_mercredientraineur_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
append_day(g_jours_entraineur,"Mercredi",gtk_toggle_button_get_active(t));
}


void
on_checkbutton_lundientraineur_toggled (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
append_day(g_jours_entraineur,"Lundi",gtk_toggle_button_get_active(t));
}


void
on_checkbutton_mardientraineur_toggled (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
append_day(g_jours_entraineur,"Mardi",gtk_toggle_button_get_active(t));
}


void
on_checkbutton_jeudientraineur_toggled (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
append_day(g_jours_entraineur,"Jeudi",gtk_toggle_button_get_active(t));
}


void
on_checkbutton_vendredientraineur_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
append_day(g_jours_entraineur,"Vendredi",gtk_toggle_button_get_active(t)); 
}


void
on_checkbutton_samedientraineur_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
append_day(g_jours_entraineur,"Samedi",gtk_toggle_button_get_active(t));
}


void
on_checkbutton_dimancheentraineur_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
append_day(g_jours_entraineur,"Dimanche",gtk_toggle_button_get_active(t)); 
}



void
on_button_ajouterentraineur_clicked    (GtkButton       *button,
                                        gpointer         user_data)
{
 GtkWidget *w = lookup_widget(GTK_WIDGET(button), "window_gestion");
    GtkWidget *tree = lookup_widget(GTK_WIDGET(button), "treeview_entraineurs");

    GtkWidget *enom = lookup_widget(GTK_WIDGET(button), "entry_nom_entraineur");
    GtkWidget *epr  = lookup_widget(GTK_WIDGET(button), "entry_prenom_entraineur");
    GtkWidget *etel = lookup_widget(GTK_WIDGET(button), "entry_tel_entraineur");
    GtkWidget *email= lookup_widget(GTK_WIDGET(button), "entry_email_entraineur");
    GtkWidget *cspec= lookup_widget(GTK_WIDGET(button), "combobox_specialite_entraineur");
    GtkWidget *ccon = lookup_widget(GTK_WIDGET(button), "combobox_contrat_entraineur");
    GtkWidget *sheu = lookup_widget(GTK_WIDGET(button), "spin_heures_entraineur");
    GtkWidget *ecout= lookup_widget(GTK_WIDGET(button), "entry_cout_entraineur");

    const char *nom = gtk_entry_get_text(GTK_ENTRY(enom));
    const char *prenom = gtk_entry_get_text(GTK_ENTRY(epr));
    const char *tel = gtk_entry_get_text(GTK_ENTRY(etel));
    const char *mail = gtk_entry_get_text(GTK_ENTRY(email));
    const char *cout = gtk_entry_get_text(GTK_ENTRY(ecout));
    int heures = (int)gtk_spin_button_get_value(GTK_SPIN_BUTTON(sheu));

    char *spec = gtk_combo_box_text_get_active_text(GTK_COMBO_BOX_TEXT(cspec));
    char *contrat = gtk_combo_box_text_get_active_text(GTK_COMBO_BOX_TEXT(ccon));

    if (!nom || !*nom || !prenom || !*prenom) { show_msg(w, GTK_MESSAGE_ERROR, "Nom/Prenom obligatoires"); goto end; }
    if (strcmp(g_sexe_entraineur,"")==0) { show_msg(w, GTK_MESSAGE_ERROR, "Choisir sexe"); goto end; }
    if (!check_phone_format(tel)) { show_msg(w, GTK_MESSAGE_ERROR, "Tel invalide: 12 345 678"); goto end; }
    if (!check_gmail_format(mail)) { show_msg(w, GTK_MESSAGE_ERROR, "Email invalide: aaaa@gmail.com"); goto end; }
    if (!spec || !contrat) { show_msg(w, GTK_MESSAGE_ERROR, "Choisir specialite et contrat"); goto end; }
    if (strcmp(g_dispo_entraineur,"")==0) { show_msg(w, GTK_MESSAGE_ERROR, "Choisir disponibilite"); goto end; }
    if (strlen(g_jours_entraineur)==0) { show_msg(w, GTK_MESSAGE_ERROR, "Choisir au moins un jour"); goto end; }
    if (heures <= 0) { show_msg(w, GTK_MESSAGE_ERROR, "Heures/semaine invalide"); goto end; }
    if (!cout || !*cout) { show_msg(w, GTK_MESSAGE_ERROR, "Cout coaching prive obligatoire"); goto end; }

    int id = next_id_from_file("entraineurs.txt");

    FILE *f = fopen("entraineurs.txt","a");
    if (!f) { show_msg(w, GTK_MESSAGE_ERROR, "Erreur fichier entraineurs.txt"); goto end; }

    fprintf(f,"%d|%s|%s|%s|%s|%s|%s|%s|%s|%s|%d|%s\n",
            id, nom, prenom, tel, mail, g_sexe_entraineur, spec, g_dispo_entraineur,
            g_jours_entraineur, contrat, heures, cout);
    fclose(f);

    init_treeview_entraineurs(tree);
    refresh_treeview_entraineurs(tree);
    show_msg(w, GTK_MESSAGE_INFO, "Entraineur ajoute.");

end:
    if (spec) g_free(spec);
    if (contrat) g_free(contrat);
}

void on_button_supprimerentraineur_clicked(GtkButton *button, gpointer user_data)
{
    GtkWidget *w = lookup_widget(GTK_WIDGET(button), "window_gestion");
    GtkWidget *tree = lookup_widget(GTK_WIDGET(button), "treeview_entraineurs");

    if (g_selected_id_entraineur < 0) { show_msg(w, GTK_MESSAGE_ERROR, "Selectionner un entraineur"); return; }

    FILE *f = fopen("entraineurs.txt","r");
    FILE *tmp = fopen("entraineurs_tmp.txt","w");
    if (!f || !tmp) { if(f)fclose(f); if(tmp)fclose(tmp); show_msg(w, GTK_MESSAGE_ERROR,"Erreur fichier"); return; }

    char line[2048];
    while (fgets(line,sizeof(line),f))
    {
        int id=0; sscanf(line,"%d|",&id);
        if (id != g_selected_id_entraineur) fputs(line,tmp);
    }
    fclose(f); fclose(tmp);
    remove("entraineurs.txt"); rename("entraineurs_tmp.txt","entraineurs.txt");

    g_selected_id_entraineur = -1;
    init_treeview_entraineurs(tree);
    refresh_treeview_entraineurs(tree);
    show_msg(w, GTK_MESSAGE_INFO, "Entraineur supprime.");
}


void
on_button_modifierentraineur_clicked   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *w = lookup_widget(GTK_WIDGET(button), "window_gestion");
    GtkWidget *tree = lookup_widget(GTK_WIDGET(button), "treeview_entraineurs");

    if (g_selected_id_entraineur < 0) { show_msg(w, GTK_MESSAGE_ERROR, "Selectionner un entraineur"); return; }

    GtkWidget *enom = lookup_widget(GTK_WIDGET(button), "entry_nom_entraineur");
    GtkWidget *epr  = lookup_widget(GTK_WIDGET(button), "entry_prenom_entraineur");
    GtkWidget *etel = lookup_widget(GTK_WIDGET(button), "entry_tel_entraineur");
    GtkWidget *email= lookup_widget(GTK_WIDGET(button), "entry_email_entraineur");
    GtkWidget *cspec= lookup_widget(GTK_WIDGET(button), "combobox_specialite_entraineur");
    GtkWidget *ccon = lookup_widget(GTK_WIDGET(button), "combobox_contrat_entraineur");
    GtkWidget *sheu = lookup_widget(GTK_WIDGET(button), "spin_heures_entraineur");
    GtkWidget *ecout= lookup_widget(GTK_WIDGET(button), "entry_cout_entraineur");

    const char *nom = gtk_entry_get_text(GTK_ENTRY(enom));
    const char *prenom = gtk_entry_get_text(GTK_ENTRY(epr));
    const char *tel = gtk_entry_get_text(GTK_ENTRY(etel));
    const char *mail = gtk_entry_get_text(GTK_ENTRY(email));
    const char *cout = gtk_entry_get_text(GTK_ENTRY(ecout));
    int heures = (int)gtk_spin_button_get_value(GTK_SPIN_BUTTON(sheu));

    char *spec = gtk_combo_box_text_get_active_text(GTK_COMBO_BOX_TEXT(cspec));
    char *contrat = gtk_combo_box_text_get_active_text(GTK_COMBO_BOX_TEXT(ccon));

    if (!check_phone_format(tel) || !check_gmail_format(mail) || !spec || !contrat ||
        strcmp(g_sexe_entraineur,"")==0 || strcmp(g_dispo_entraineur,"")==0 || strlen(g_jours_entraineur)==0 ||
        heures<=0 || !cout || !*cout)
    {
        show_msg(w, GTK_MESSAGE_ERROR, "Donnees invalides");
        if (spec) g_free(spec);
        if (contrat) g_free(contrat);
        return;
    }

    FILE *f = fopen("entraineurs.txt","r");
    FILE *tmp = fopen("entraineurs_tmp.txt","w");
    if (!f || !tmp) { if(f)fclose(f); if(tmp)fclose(tmp); show_msg(w, GTK_MESSAGE_ERROR,"Erreur fichier"); goto end; }

    char line[2048];
    while (fgets(line,sizeof(line),f))
    {
        int id=0; sscanf(line,"%d|",&id);
        if (id == g_selected_id_entraineur)
        {
            fprintf(tmp,"%d|%s|%s|%s|%s|%s|%s|%s|%s|%s|%d|%s\n",
                id, nom, prenom, tel, mail, g_sexe_entraineur, spec, g_dispo_entraineur,
                g_jours_entraineur, contrat, heures, cout);
        }
        else fputs(line,tmp);
    }
    fclose(f); fclose(tmp);
    remove("entraineurs.txt"); rename("entraineurs_tmp.txt","entraineurs.txt");

    init_treeview_entraineurs(tree);
    refresh_treeview_entraineurs(tree);
    show_msg(w, GTK_MESSAGE_INFO, "Entraineur modifie.");

end:
    if (spec) g_free(spec);
    if (contrat) g_free(contrat);
}


void
on_button_supprimerentraineur_clicked  (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_validerentraineur_clicked    (GtkButton       *button,
                                        gpointer         user_data)
{
 GtkWidget *w = lookup_widget(GTK_WIDGET(button), "window_gestion");
    show_msg(w, GTK_MESSAGE_INFO, "Validation OK.");
}


void
on_button_fermerentraineur_clicked     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *w = lookup_widget(GTK_WIDGET(button), "window_gestion");
    gtk_widget_hide(w);
}


void
on_button_rechercherentraineur_clicked (GtkButton       *button,
                                        gpointer         user_data)
{
 GtkWidget *w = lookup_widget(GTK_WIDGET(button), "window_gestion");
    GtkWidget *tree = lookup_widget(GTK_WIDGET(button), "treeview_entraineurs");
    GtkWidget *erech = lookup_widget(GTK_WIDGET(button), "entry_recherche_entraineur");
    const char *key = gtk_entry_get_text(GTK_ENTRY(erech));

    if (!key || !*key)
    {
        init_treeview_entraineurs(tree);
        refresh_treeview_entraineurs(tree);
        return;
    }

    GtkListStore *store = gtk_list_store_new(12,
        G_TYPE_INT, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,
        G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,
        G_TYPE_INT, G_TYPE_STRING);

    int key_is_id = is_int_str(key);
    int idkey = key_is_id ? atoi(key) : -1;

    FILE *f = fopen("entraineurs.txt","r");
    if (!f) { show_msg(w, GTK_MESSAGE_ERROR, "entraineurs.txt introuvable"); return; }

    char line[2048];
    while (fgets(line,sizeof(line),f))
    {
        int id, heures;
        char nom[100], prenom[100], tel[50], email[120], sexe[20];
        char spec[60], dispo[40], jours[120], contrat[40], cout[60];

        if (sscanf(line,
            "%d|%99[^|]|%99[^|]|%49[^|]|%119[^|]|%19[^|]|%59[^|]|%39[^|]|%119[^|]|%39[^|]|%d|%59[^\n]",
            &id, nom, prenom, tel, email, sexe, spec, dispo, jours, contrat, &heures, cout) == 12)
        {
            int ok = 0;
            if (key_is_id && id == idkey) ok = 1;
            if (!key_is_id && strstr(nom, key)) ok = 1;

            if (ok)
            {
                GtkTreeIter it;
                gtk_list_store_append(store,&it);
                gtk_list_store_set(store,&it,
                    0,id,1,nom,2,prenom,3,tel,4,email,5,sexe,6,spec,7,dispo,8,jours,9,contrat,10,heures,11,cout,-1);
            }
        }
    }
    fclose(f);

    gtk_tree_view_set_model(GTK_TREE_VIEW(tree), GTK_TREE_MODEL(store));
    g_object_unref(store);
}

void on_button_validerentraineur_clicked(GtkButton *button, gpointer user_data)
{
    GtkWidget *w = lookup_widget(GTK_WIDGET(button), "window_gestion");
    show_msg(w, GTK_MESSAGE_INFO, "Validation OK.");
}


void
on_radiobutton_femmeentraineur_toggled (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
 if (gtk_toggle_button_get_active(togglebutton)) strcpy(g_sexe_entraineur, "Femme");
}


void
on_treeview_cours_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_checkbutton_publiccours_toggled     (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_checkbutton_privecours_toggled      (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_radiobutton_debutantecours_toggled  (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_radiobutton_intermediairecours_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_radiobutton_avancecours_toggled     (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_button_ajoutercours_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
    GtkWidget *w = lookup_widget(GTK_WIDGET(button),"window_gestion");
    GtkWidget *tree = lookup_widget(GTK_WIDGET(button),"treeview_cours");

    GtkWidget *cnom = lookup_widget(GTK_WIDGET(button),"combobox_nom_cours");
    GtkWidget *cent = lookup_widget(GTK_WIDGET(button),"combobox_entraineur_cours");
    GtkWidget *ccen = lookup_widget(GTK_WIDGET(button),"combobox_centre_cours");
    GtkWidget *cjour= lookup_widget(GTK_WIDGET(button),"combobox_jour_cours");

    GtkWidget *sheu = lookup_widget(GTK_WIDGET(button),"spin_heure_cours");
    GtkWidget *sdur = lookup_widget(GTK_WIDGET(button),"spin_duree_cours");
    GtkWidget *sj   = lookup_widget(GTK_WIDGET(button),"spin_jour_date_cours");
    GtkWidget *sm   = lookup_widget(GTK_WIDGET(button),"spin_mois_date_cours");
    GtkWidget *sa   = lookup_widget(GTK_WIDGET(button),"spin_annee_date_cours");

    char *nomcours = gtk_combo_box_text_get_active_text(GTK_COMBO_BOX_TEXT(cnom));
    char *entraineur = gtk_combo_box_text_get_active_text(GTK_COMBO_BOX_TEXT(cent));
    char *centre = gtk_combo_box_text_get_active_text(GTK_COMBO_BOX_TEXT(ccen));
    char *jour = gtk_combo_box_text_get_active_text(GTK_COMBO_BOX_TEXT(cjour));

    int heure = (int)gtk_spin_button_get_value(GTK_SPIN_BUTTON(sheu));
    int duree = (int)gtk_spin_button_get_value(GTK_SPIN_BUTTON(sdur));
    int dj = (int)gtk_spin_button_get_value(GTK_SPIN_BUTTON(sj));
    int dm = (int)gtk_spin_button_get_value(GTK_SPIN_BUTTON(sm));
    int da = (int)gtk_spin_button_get_value(GTK_SPIN_BUTTON(sa));

    if (!nomcours || !entraineur || !centre || !jour) { show_msg(w,GTK_MESSAGE_ERROR,"Choisir cours/entraineur/centre/jour"); goto end; }
    if (duree < 1 || duree > 3) { show_msg(w,GTK_MESSAGE_ERROR,"Duree doit etre 1..3"); goto end; }
    if (!is_valid_date(dj,dm,da)) { show_msg(w,GTK_MESSAGE_ERROR,"Date invalide (>=2025)"); goto end; }
    if (strcmp(g_niveau_cours,"")==0) { show_msg(w,GTK_MESSAGE_ERROR,"Choisir niveau"); goto end; }
    if (strcmp(g_type_cours,"")==0) { show_msg(w,GTK_MESSAGE_ERROR,"Choisir type"); goto end; }

    int id = next_id_from_file("cours.txt");
    char date[40]; sprintf(date,"%02d/%02d/%04d",dj,dm,da);

    FILE *f = fopen("cours.txt","a");
    if (!f) { show_msg(w,GTK_MESSAGE_ERROR,"Erreur cours.txt"); goto end; }

    fprintf(f,"%d|%s|%s|%s|%d|%s|%d|%s|%s|%s\n",
            id, nomcours, entraineur, centre, heure, jour, duree, date, g_niveau_cours, g_type_cours);
    fclose(f);

    init_treeview_cours(tree);
    refresh_treeview_cours(tree);
    show_msg(w,GTK_MESSAGE_INFO,"Cours ajoute.");

end:
    if (nomcours) g_free(nomcours);
    if (entraineur) g_free(entraineur);
    if (centre) g_free(centre);
    if (jour) g_free(jour);
}


void
on_button_modifiercours_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{
   GtkWidget *w = lookup_widget(GTK_WIDGET(button),"window_gestion");
    GtkWidget *tree = lookup_widget(GTK_WIDGET(button),"treeview_cours");
    if (g_selected_id_cours < 0) { show_msg(w,GTK_MESSAGE_ERROR,"Selectionner un cours"); return; }

    /* même lecture champs que ajouter */
    GtkWidget *cnom = lookup_widget(GTK_WIDGET(button),"combobox_nom_cours");
    GtkWidget *cent = lookup_widget(GTK_WIDGET(button),"combobox_entraineur_cours");
    GtkWidget *ccen = lookup_widget(GTK_WIDGET(button),"combobox_centre_cours");
    GtkWidget *cjour= lookup_widget(GTK_WIDGET(button),"combobox_jour_cours");

    GtkWidget *sheu = lookup_widget(GTK_WIDGET(button),"spin_heure_cours");
    GtkWidget *sdur = lookup_widget(GTK_WIDGET(button),"spin_duree_cours");
    GtkWidget *sj   = lookup_widget(GTK_WIDGET(button),"spin_jour_date_cours");
    GtkWidget *sm   = lookup_widget(GTK_WIDGET(button),"spin_mois_date_cours");
    GtkWidget *sa   = lookup_widget(GTK_WIDGET(button),"spin_annee_date_cours");

    char *nomcours = gtk_combo_box_text_get_active_text(GTK_COMBO_BOX_TEXT(cnom));
    char *entraineur = gtk_combo_box_text_get_active_text(GTK_COMBO_BOX_TEXT(cent));
    char *centre = gtk_combo_box_text_get_active_text(GTK_COMBO_BOX_TEXT(ccen));
    char *jour = gtk_combo_box_text_get_active_text(GTK_COMBO_BOX_TEXT(cjour));

    int heure = (int)gtk_spin_button_get_value(GTK_SPIN_BUTTON(sheu));
    int duree = (int)gtk_spin_button_get_value(GTK_SPIN_BUTTON(sdur));
    int dj = (int)gtk_spin_button_get_value(GTK_SPIN_BUTTON(sj));
    int dm = (int)gtk_spin_button_get_value(GTK_SPIN_BUTTON(sm));
    int da = (int)gtk_spin_button_get_value(GTK_SPIN_BUTTON(sa));

    if (!nomcours || !entraineur || !centre || !jour || duree<1 || duree>3 ||
        !is_valid_date(dj,dm,da) || strcmp(g_niveau_cours,"")==0 || strcmp(g_type_cours,"")==0)
    {
        show_msg(w,GTK_MESSAGE_ERROR,"Donnees invalides");
        goto end;
    }

    char date[40]; sprintf(date,"%02d/%02d/%04d",dj,dm,da);

    FILE *f=fopen("cours.txt","r");
    FILE *tmp=fopen("cours_tmp.txt","w");
    if(!f||!tmp){ if(f)fclose(f); if(tmp)fclose(tmp); show_msg(w,GTK_MESSAGE_ERROR,"Erreur fichier"); goto end; }

    char line[2048];
    while(fgets(line,sizeof(line),f))
    {
        int id=0; sscanf(line,"%d|",&id);
        if(id==g_selected_id_cours)
            fprintf(tmp,"%d|%s|%s|%s|%d|%s|%d|%s|%s|%s\n",
                    id, nomcours, entraineur, centre, heure, jour, duree, date, g_niveau_cours, g_type_cours);
        else fputs(line,tmp);
    }
    fclose(f); fclose(tmp);
    remove("cours.txt"); rename("cours_tmp.txt","cours.txt");

    init_treeview_cours(tree);
    refresh_treeview_cours(tree);
    show_msg(w,GTK_MESSAGE_INFO,"Cours modifie.");

end:
    if (nomcours) g_free(nomcours);
    if (entraineur) g_free(entraineur);
    if (centre) g_free(centre);
    if (jour) g_free(jour);
}


void
on_button_supprimercours_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{
 GtkWidget *w = lookup_widget(GTK_WIDGET(button),"window_gestion");
    GtkWidget *tree = lookup_widget(GTK_WIDGET(button),"treeview_cours");

    if (g_selected_id_cours < 0) { show_msg(w,GTK_MESSAGE_ERROR,"Selectionner un cours"); return; }

    FILE *f=fopen("cours.txt","r");
    FILE *tmp=fopen("cours_tmp.txt","w");
    if (!f||!tmp) { if(f)fclose(f); if(tmp)fclose(tmp); show_msg(w,GTK_MESSAGE_ERROR,"Erreur fichier"); return; }

    char line[2048];
    while (fgets(line,sizeof(line),f))
    {
        int id=0; sscanf(line,"%d|",&id);
        if (id != g_selected_id_cours) fputs(line,tmp);
    }
    fclose(f); fclose(tmp);
    remove("cours.txt"); rename("cours_tmp.txt","cours.txt");

    g_selected_id_cours=-1;
    init_treeview_cours(tree);
    refresh_treeview_cours(tree);
    show_msg(w,GTK_MESSAGE_INFO,"Cours supprime.");
}


void
on_button_validercours_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *w = lookup_widget(GTK_WIDGET(button), "window_gestion");
    show_msg(w, GTK_MESSAGE_INFO, "Validation OK.");
}


void
on_button_fermercours_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *w = lookup_widget(GTK_WIDGET(button), "window_gestion");
    gtk_widget_hide(w);
}


void
on_button_recherchercours_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{
 GtkWidget *w=lookup_widget(GTK_WIDGET(button),"window_gestion");
    GtkWidget *tree=lookup_widget(GTK_WIDGET(button),"treeview_cours");
    GtkWidget *erech=lookup_widget(GTK_WIDGET(button),"entry_rechercher_cours");
    const char *key=gtk_entry_get_text(GTK_ENTRY(erech));

    if(!key||!*key){ init_treeview_cours(tree); refresh_treeview_cours(tree); return; }

    GtkListStore *store=gtk_list_store_new(10,
        G_TYPE_INT,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_STRING,G_TYPE_INT,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

    int key_is_id=is_int_str(key);
    int idkey= key_is_id?atoi(key):-1;

    FILE *f=fopen("cours.txt","r");
    if(!f){ show_msg(w,GTK_MESSAGE_ERROR,"cours.txt introuvable"); return; }

    char line[2048];
    while(fgets(line,sizeof(line),f))
    {
        int id,heure,duree;
        char nomcours[60], ent[80], centre[120], jour[30], date[40], niveau[30], type[30];

        if(sscanf(line,"%d|%59[^|]|%79[^|]|%119[^|]|%d|%29[^|]|%d|%39[^|]|%29[^|]|%29[^\n]",
                  &id,nomcours,ent,centre,&heure,jour,&duree,date,niveau,type)==10)
        {
            int ok=0;
            if(key_is_id && id==idkey) ok=1;
            if(!key_is_id && strstr(nomcours,key)) ok=1;

            if(ok)
            {
                GtkTreeIter it; gtk_list_store_append(store,&it);
                gtk_list_store_set(store,&it,0,id,1,nomcours,2,ent,3,centre,4,heure,5,jour,6,duree,7,date,8,niveau,9,type,-1);
            }
        }
    }
    fclose(f);
    gtk_tree_view_set_model(GTK_TREE_VIEW(tree),GTK_TREE_MODEL(store));
    g_object_unref(store);
}


void
on_treeview_equipement_row_activated   (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
 GtkTreeIter iter;
    GtkTreeModel *model = gtk_tree_view_get_model(treeview);
    if (gtk_tree_model_get_iter(model, &iter, path))
    {
        int id;
        gtk_tree_model_get(model, &iter, 0, &id, -1);
        g_selected_id_entraineur = id;
    }
}





void
on_radiobutton_sfitnesse_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
 if (gtk_toggle_button_get_active(togglebutton)) strcpy(g_sexe_entraineur, "Homme");
}


void
on_radiobutton_smusculation_toggled    (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
 if (gtk_toggle_button_get_active(togglebutton)) strcpy(g_sexe_entraineur, "Femme");
}


void
on_radiobutton_sdance_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(t)) strcpy(g_salle_type,"S.danse");
}


void
on_checkbutton_consommable_toggled     (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
g_consommable = gtk_toggle_button_get_active(t) ? 1 : 0;

}


void
on_radiobutton_sboxe_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(t)) strcpy(g_salle_type,"S.boxe");
}


void
on_treeview_centre_row_activated       (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
    GtkTreeModel *model=gtk_tree_view_get_model(treeview);
    if(gtk_tree_model_get_iter(model,&iter,path))
    {
        int id; gtk_tree_model_get(model,&iter,0,&id,-1);
        g_selected_id_centre=id;
    }
}


void
on_recherche_centre_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
 GtkWidget *w=lookup_widget(GTK_WIDGET(button),"window_gestion");
    GtkWidget *tree=lookup_widget(GTK_WIDGET(button),"treeview_centre");
    GtkWidget *erech=lookup_widget(GTK_WIDGET(button),"entry_recherche_centre");
    const char *key=gtk_entry_get_text(GTK_ENTRY(erech));

    if(!key||!*key){ init_treeview_centre(tree); refresh_treeview_centre(tree); return; }

    GtkListStore *store=gtk_list_store_new(8,
        G_TYPE_INT,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_STRING);

    int key_is_id=is_int_str(key);
    int idkey= key_is_id?atoi(key):-1;

    FILE *f=fopen("centres.txt","r");
    if(!f){ show_msg(w,GTK_MESSAGE_ERROR,"centres.txt introuvable"); return; }

    char line[2048];
    while(fgets(line,sizeof(line),f))
    {
        int id, coaches, membres, salles, capacite;
        char nom[120], adresse[80], etat[20];

        if(sscanf(line,"%d|%119[^|]|%79[^|]|%d|%d|%d|%d|%19[^\n]",
                  &id,nom,adresse,&coaches,&membres,&salles,&capacite,etat)==8)
        {
            int ok=0;
            if(key_is_id && id==idkey) ok=1;
            if(!key_is_id && strstr(nom,key)) ok=1;

            if(ok)
            {
                GtkTreeIter it; gtk_list_store_append(store,&it);
                gtk_list_store_set(store,&it,0,id,1,nom,2,adresse,3,coaches,4,membres,5,salles,6,capacite,7,etat,-1);
            }
        }
    }
    fclose(f);

    gtk_tree_view_set_model(GTK_TREE_VIEW(tree),GTK_TREE_MODEL(store));
    g_object_unref(store);
}


void
on_etat_actif_centre_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(tm)) strcpy(g_etat_centre,"Actif");
}


void
on_ajouter_centre_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
  GtkWidget *w=lookup_widget(GTK_WIDGET(button),"window_gestion");
    GtkWidget *tree=lookup_widget(GTK_WIDGET(button),"treeview_centre");

    GtkWidget *enom=lookup_widget(GTK_WIDGET(button),"entry_nom_centre");
    GtkWidget *cad=lookup_widget(GTK_WIDGET(button),"combobox_adresse_centre");
    GtkWidget *sco=lookup_widget(GTK_WIDGET(button),"spin_coaches_centre");
    GtkWidget *sme=lookup_widget(GTK_WIDGET(button),"spin_membres_centre");
    GtkWidget *ssa=lookup_widget(GTK_WIDGET(button),"spin_salles_centre");
    GtkWidget *sca=lookup_widget(GTK_WIDGET(button),"spin_capacite_centre");

    const char *nom=gtk_entry_get_text(GTK_ENTRY(enom));
    char *adresse=gtk_combo_box_text_get_active_text(GTK_COMBO_BOX_TEXT(cad));

    int coaches=(int)gtk_spin_button_get_value(GTK_SPIN_BUTTON(sco));
    int membres=(int)gtk_spin_button_get_value(GTK_SPIN_BUTTON(sme));
    int salles=(int)gtk_spin_button_get_value(GTK_SPIN_BUTTON(ssa));
    int capacite=(int)gtk_spin_button_get_value(GTK_SPIN_BUTTON(sca));

    if(!nom||!*nom){ show_msg(w,GTK_MESSAGE_ERROR,"Nom centre obligatoire"); goto end; }
    if(!adresse){ show_msg(w,GTK_MESSAGE_ERROR,"Choisir adresse"); goto end; }
    if(strcmp(g_etat_centre,"")==0){ show_msg(w,GTK_MESSAGE_ERROR,"Choisir etat Actif/Inactif"); goto end; }
    if(coaches<0||membres<0||salles<=0||capacite<=0){ show_msg(w,GTK_MESSAGE_ERROR,"Valeurs invalides"); goto end; }

    int id=next_id_from_file("centres.txt");
    FILE *f=fopen("centres.txt","a");
    if(!f){ show_msg(w,GTK_MESSAGE_ERROR,"Erreur centres.txt"); goto end; }

    fprintf(f,"%d|%s|%s|%d|%d|%d|%d|%s\n",id,nom,adresse,coaches,membres,salles,capacite,g_etat_centre);
    fclose(f);

    init_treeview_centre(tree);
    refresh_treeview_centre(tree);
    show_msg(w,GTK_MESSAGE_INFO,"Centre ajoute.");

end:
    if(adresse) g_free(adresse);
}


void
on_modifier_centre_enter               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *w=lookup_widget(GTK_WIDGET(button),"window_gestion");
    GtkWidget *tree=lookup_widget(GTK_WIDGET(button),"treeview_centre");

    if(g_selected_id_centre<0){ show_msg(w,GTK_MESSAGE_ERROR,"Selectionner un centre"); return; }

    GtkWidget *enom=lookup_widget(GTK_WIDGET(button),"entry_nom_centre");
    GtkWidget *cad=lookup_widget(GTK_WIDGET(button),"combobox_adresse_centre");
    GtkWidget *sco=lookup_widget(GTK_WIDGET(button),"spin_coaches_centre");
    GtkWidget *sme=lookup_widget(GTK_WIDGET(button),"spin_membres_centre");
    GtkWidget *ssa=lookup_widget(GTK_WIDGET(button),"spin_salles_centre");
    GtkWidget *sca=lookup_widget(GTK_WIDGET(button),"spin_capacite_centre");

    const char *nom=gtk_entry_get_text(GTK_ENTRY(enom));
    char *adresse=gtk_combo_box_text_get_active_text(GTK_COMBO_BOX_TEXT(cad));
    int coaches=(int)gtk_spin_button_get_value(GTK_SPIN_BUTTON(sco));
    int membres=(int)gtk_spin_button_get_value(GTK_SPIN_BUTTON(sme));
    int salles=(int)gtk_spin_button_get_value(GTK_SPIN_BUTTON(ssa));
    int capacite=(int)gtk_spin_button_get_value(GTK_SPIN_BUTTON(sca));

    if(!nom||!*nom||!adresse||strcmp(g_etat_centre,"")==0||salles<=0||capacite<=0)
    { show_msg(w,GTK_MESSAGE_ERROR,"Donnees invalides"); goto end; }

    FILE *f=fopen("centres.txt","r");
    FILE *tmp=fopen("centres_tmp.txt","w");
    if(!f||!tmp){ if(f)fclose(f); if(tmp)fclose(tmp); show_msg(w,GTK_MESSAGE_ERROR,"Erreur fichier"); goto end; }

    char line[2048];
    while(fgets(line,sizeof(line),f))
    {
        int id=0; sscanf(line,"%d|",&id);
        if(id==g_selected_id_centre)
            fprintf(tmp,"%d|%s|%s|%d|%d|%d|%d|%s\n",id,nom,adresse,coaches,membres,salles,capacite,g_etat_centre);
        else fputs(line,tmp);
    }
    fclose(f); fclose(tmp);
    remove("centres.txt"); rename("centres_tmp.txt","centres.txt");

    init_treeview_centre(tree);
    refresh_treeview_centre(tree);
    show_msg(w,GTK_MESSAGE_INFO,"Centre modifie.");

end:
    if(adresse) g_free(adresse);
}


void
on_supprimer_centre_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *w=lookup_widget(GTK_WIDGET(button),"window_gestion");
    GtkWidget *tree=lookup_widget(GTK_WIDGET(button),"treeview_centre");

    if(g_selected_id_centre<0){ show_msg(w,GTK_MESSAGE_ERROR,"Selectionner un centre"); return; }

    FILE *f=fopen("centres.txt","r");
    FILE *tmp=fopen("centres_tmp.txt","w");
    if(!f||!tmp){ if(f)fclose(f); if(tmp)fclose(tmp); show_msg(w,GTK_MESSAGE_ERROR,"Erreur fichier"); return; }

    char line[2048];
    while(fgets(line,sizeof(line),f))
    {
        int id=0; sscanf(line,"%d|",&id);
        if(id!=g_selected_id_centre) fputs(line,tmp);
    }
    fclose(f); fclose(tmp);
    remove("centres.txt"); rename("centres_tmp.txt","centres.txt");

    g_selected_id_centre=-1;
    init_treeview_centre(tree);
    refresh_treeview_centre(tree);
    show_msg(w,GTK_MESSAGE_INFO,"Centre supprime.");
}


void
on_button_valider_centre_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *w=lookup_widget(GTK_WIDGET(button),"window_gestion");
    show_msg(w,GTK_MESSAGE_INFO,"Validation OK.");
}


void
on_button_fermer_centre_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *w=lookup_widget(GTK_WIDGET(button),"window_gestion");
    gtk_widget_hide(w);
}


void
on_etat_inactif_centre_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(t)) strcpy(g_etat_centre,"Inactif");
}



void
on_radiobutton_mixtecoursprv_toggled   (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_radiobutton_unisexcoursprv_toggled  (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_button_fermercoursprv_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_validercoursprv_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_checkbutton_lundicoachprv_toggled   (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_checkbutton_mardicoachprv_toggled   (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_checkbutton_mercredicoachprv_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_checkbutton_jeudicoachprv_toggled   (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_checkbutton_vendredicoachprv_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_checkbutton_samedicoachprv_toggled  (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_checkbutton_dimanchecoachprv_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_checkbutton_touscoachprv_toggled    (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_inscrire_centre_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_reserverequipement_clicked   (GtkButton       *button,
                                        gpointer         user_data)
{

}

void
on_radiobutton_sfitnessereserver_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_smusculationreserver_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_sdancereserver_toggled  (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_sboxreeserver_toggled   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);


void
on_button_annulerreservation_clicked   (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_seconnecteradmin_clicked     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *w_admin, *euser, *epass, *dialog, *w_gestion;
    const char *user, *pass;
    FILE *f;
    char file_user[256], file_pass[256];

    w_admin = lookup_widget(GTK_WIDGET(button), "window_admin");

    euser = lookup_widget(GTK_WIDGET(button), "entry_username_admin");
    epass = lookup_widget(GTK_WIDGET(button), "entry_password_admin");

    user = gtk_entry_get_text(GTK_ENTRY(euser));
    pass = gtk_entry_get_text(GTK_ENTRY(epass));

    f = fopen("loginadmin.txt", "r");
    if (f == NULL)
    {
        dialog = gtk_message_dialog_new(GTK_WINDOW(w_admin),
                                        GTK_DIALOG_MODAL,
                                        GTK_MESSAGE_ERROR,
                                        GTK_BUTTONS_OK,
                                        "Impossible d'ouvrir loginadmin.txt");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
        return;
    }

    fgets(file_user, sizeof(file_user), f);
    fgets(file_pass, sizeof(file_pass), f);
    fclose(f);

    file_user[strcspn(file_user, "\r\n")] = 0;
    file_pass[strcspn(file_pass, "\r\n")] = 0;

    if (strcmp(file_user, user) == 0 && strcmp(file_pass, pass) == 0)
    {
        w_gestion = create_window_gestion();
        gtk_widget_hide(w_admin);
        gtk_widget_show(w_gestion);
    }
    else
    {
        dialog = gtk_message_dialog_new(GTK_WINDOW(w_admin),
                                        GTK_DIALOG_MODAL,
                                        GTK_MESSAGE_ERROR,
                                        GTK_BUTTONS_OK,
                                        "Nom d'utilisateur ou mot de passe incorrect (Admin) !");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
    }
}


void
on_button_seconnecterentraineur_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *w_entraineur, *euser, *epass, *dialog, *w_choix;
    const char *user, *pass;
    FILE *f;
    char file_user[256], file_pass[256];

    w_entraineur = lookup_widget(GTK_WIDGET(button), "window_entraineur");

    euser = lookup_widget(GTK_WIDGET(button), "entry_username_entraineur");
    epass = lookup_widget(GTK_WIDGET(button), "entry_password_entraineur");

    user = gtk_entry_get_text(GTK_ENTRY(euser));
    pass = gtk_entry_get_text(GTK_ENTRY(epass));

    f = fopen("loginentraineur.txt", "r");
    if (f == NULL)
    {
        dialog = gtk_message_dialog_new(GTK_WINDOW(w_entraineur),
                                        GTK_DIALOG_MODAL,
                                        GTK_MESSAGE_ERROR,
                                        GTK_BUTTONS_OK,
                                        "Impossible d'ouvrir loginentraineur.txt");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
        return;
    }

    fgets(file_user, sizeof(file_user), f);
    fgets(file_pass, sizeof(file_pass), f);
    fclose(f);

    file_user[strcspn(file_user, "\r\n")] = 0;
    file_pass[strcspn(file_pass, "\r\n")] = 0;

    if (strcmp(file_user, user) == 0 && strcmp(file_pass, pass) == 0)
    {
        w_choix = create_window_choixentraineur();
        gtk_widget_hide(w_entraineur);
        gtk_widget_show(w_choix);
    }
    else
    {
        dialog = gtk_message_dialog_new(GTK_WINDOW(w_entraineur),
                                        GTK_DIALOG_MODAL,
                                        GTK_MESSAGE_ERROR,
                                        GTK_BUTTONS_OK,
                                        "Nom d'utilisateur ou mot de passe incorrect (Entraineur) !");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
    }
}


void
on_button_seconnectermembre_clicked    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *w_membre, *euser, *epass, *dialog, *w_choix;
    const char *user, *pass;
    FILE *f;
    char file_user[256], file_pass[256];

    w_membre = lookup_widget(GTK_WIDGET(button), "window_membre");

    euser = lookup_widget(GTK_WIDGET(button), "entry_username_membre");
    epass = lookup_widget(GTK_WIDGET(button), "entry_password_membre");

    user = gtk_entry_get_text(GTK_ENTRY(euser));
    pass = gtk_entry_get_text(GTK_ENTRY(epass));

    f = fopen("loginmembre.txt", "r");
    if (f == NULL)
    {
        dialog = gtk_message_dialog_new(GTK_WINDOW(w_membre),
                                        GTK_DIALOG_MODAL,
                                        GTK_MESSAGE_ERROR,
                                        GTK_BUTTONS_OK,
                                        "Impossible d'ouvrir loginmembre.txt");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
        return;
    }

    fgets(file_user, sizeof(file_user), f);
    fgets(file_pass, sizeof(file_pass), f);
    fclose(f);

    file_user[strcspn(file_user, "\r\n")] = 0;
    file_pass[strcspn(file_pass, "\r\n")] = 0;

    if (strcmp(file_user, user) == 0 && strcmp(file_pass, pass) == 0)
    {
        w_choix = create_window_choixmembre();
        gtk_widget_hide(w_membre);
        gtk_widget_show(w_choix);
    }
    else
    {
        dialog = gtk_message_dialog_new(GTK_WINDOW(w_membre),
                                        GTK_DIALOG_MODAL,
                                        GTK_MESSAGE_ERROR,
                                        GTK_BUTTONS_OK,
                                        "Nom d'utilisateur ou mot de passe incorrect (Membre) !");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
    }
}


void
on_button_entraineur_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *w_welcome, *w_entraineur;

    w_welcome = lookup_widget(GTK_WIDGET(button), "window_welcome");
    w_entraineur = create_window_entraineur();

    gtk_widget_hide(w_welcome);
    gtk_widget_show(w_entraineur);
}


void
on_button_admin_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *w_welcome, *w_admin;

    w_welcome = lookup_widget(GTK_WIDGET(button), "window_welcome");
    w_admin = create_window_admin();

    gtk_widget_hide(w_welcome);
    gtk_widget_show(w_admin);
}


void
on_button_membre_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *w_welcome, *w_membre;

    w_welcome = lookup_widget(GTK_WIDGET(button), "window_welcome");
    w_membre = create_window_membre();

    gtk_widget_hide(w_welcome);
    gtk_widget_show(w_membre);
}


void
on_button_sinscrireauncours_clicked    (GtkButton       *button,
                                        gpointer         user_data)
{

}

