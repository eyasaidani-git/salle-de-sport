#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>   /* strcasecmp */
#include "coursprv.h"

#define F_COURS "cours.txt"
#define F_PRV   "coursprv.txt"

/* représentation d'un cours lu depuis cours.txt */
typedef struct
{
    int id;
    int cours_num;
    char cours_nom[128];
    char entraineur[128];
    char centre[128];
    int heure;
    char jour[128];
    int duree;
    int j, m, a;
    char niveau[128];
    char type[128]; /* Publique/Prive */
} Cours;

void menu(void);
int lire_int(const char *msg, int min, int max);
void lire_ligne(const char *msg, char *out, int outsz);

int charger_cours_prives(Cours t[], int max);
int liste_noms_cours_prives(char noms[][128], int max_noms);
int choisir_nom_cours(char *out, int outsz);
int afficher_offres_et_choisir(Cours t[], int n, const char *nom_cours);

/* ===== main ===== */
int main(void)
{
    int ch;

    do {
        menu();
        ch = lire_int("Choix: ", 0, 2);

        switch(ch)
        {
            case 1: /* Afficher cours privés */
            {
                Cours t[500];
                int n = charger_cours_prives(t, 500);
                if(n <= 0) { printf("Aucun cours prive trouve.\n"); break; }

                printf("\n--- Cours prives disponibles (depuis cours.txt) ---\n");
                for(int i=0;i<n;i++)
                {
                    printf("%d) IDcours=%d | %s | %s | %s | %dh | %s | %dh | %02d/%02d/%04d | %s\n",
                           i+1, t[i].id, t[i].cours_nom, t[i].entraineur, t[i].centre,
                           t[i].heure, t[i].jour, t[i].duree, t[i].j, t[i].m, t[i].a, t[i].niveau);
                }
            }
            break;

            case 2: /* S'inscrire */
            {
                char membre[128];
                char nom_cours[128];
                char genre[128];

                lire_ligne("Nom et prenom membre: ", membre, sizeof(membre));
                if(strlen(membre)==0) { printf("Nom membre obligatoire.\n"); break; }

                if(!choisir_nom_cours(nom_cours, sizeof(nom_cours)))
                    break;

                /* charger tous les cours privés */
                Cours t[500];
                int n = charger_cours_prives(t, 500);
                if(n <= 0) { printf("Aucun cours prive.\n"); break; }

                /* choisir l'offre exacte (entraîneur/centre/horaire...) */
                int idx = afficher_offres_et_choisir(t, n, nom_cours);
                if(idx < 0) break;

                /* choisir genre */
                printf("\nGenre semantique:\n1 - Mixte\n2 - Unisex\n");
                int g = lire_int("Numero: ", 1, 2);
                strcpy(genre, (g==1) ? "Mixte" : "Unisex");

                /* construire inscription */
                InscriptionPrv insc;
                memset(&insc, 0, sizeof(insc));

                insc.id_insc = prv_next_id(F_PRV);
                strncpy(insc.membre, membre, 128-1);

                insc.id_cours = t[idx].id;
                strncpy(insc.cours, t[idx].cours_nom, 128-1);
                strncpy(insc.entraineur, t[idx].entraineur, 128-1);
                strncpy(insc.centre, t[idx].centre, 128-1);
                insc.heure = t[idx].heure;
                strncpy(insc.jour, t[idx].jour, 128-1);
                insc.duree = t[idx].duree;
                insc.j = t[idx].j; insc.m = t[idx].m; insc.a = t[idx].a;
                strncpy(insc.niveau, t[idx].niveau, 128-1);
                strncpy(insc.genre, genre, 128-1);

                if(prv_ajouter(F_PRV, insc))
                    printf("OK: inscription enregistree dans coursprv.txt (ID=%d)\n", insc.id_insc);
                else
                    printf("Erreur: echec ecriture coursprv.txt\n");
            }
            break;

            case 0:
                printf("Au revoir.\n");
            break;
        }

    } while(ch != 0);

    return 0;
}

/* ===== Fonctions ===== */

void menu(void)
{
    printf("\n========== Inscription Cours Prive ==========\n");
    printf("1) Afficher les cours prives disponibles\n");
    printf("2) S'inscrire a un cours prive\n");
    printf("0) Quitter\n");
    printf("============================================\n");
}

int lire_int(const char *msg, int min, int max)
{
    int x;
    do {
        printf("%s", msg);
        if(scanf("%d", &x) != 1)
        {
            while(getchar() != '\n');
            x = min - 1;
        }
        else while(getchar() != '\n');
    } while(x < min || x > max);
    return x;
}

void lire_ligne(const char *msg, char *out, int outsz)
{
    printf("%s", msg);
    fgets(out, outsz, stdin);
    out[strcspn(out, "\r\n")] = '\0';
}

/* lire cours.txt et garder seulement type=Prive */
int charger_cours_prives(Cours t[], int max)
{
    FILE *f = fopen(F_COURS, "r");
    if(!f) return 0;

    int n = 0;
    while(n < max &&
          fscanf(f,
            "%d;%d;%127[^;];%127[^;];%127[^;];%d;%127[^;];%d;%d/%d/%d;%127[^;];%127[^\n]\n",
            &t[n].id, &t[n].cours_num, t[n].cours_nom, t[n].entraineur, t[n].centre,
            &t[n].heure, t[n].jour, &t[n].duree, &t[n].j, &t[n].m, &t[n].a,
            t[n].niveau, t[n].type) != EOF)
    {
        if(strcasecmp(t[n].type, "Prive") == 0)
            n++;
    }

    fclose(f);
    return n;
}

/* liste unique des noms de cours privés (Aerobic/yoga/pilates/zumba) */
int liste_noms_cours_prives(char noms[][128], int max_noms)
{
    Cours t[500];
    int n = charger_cours_prives(t, 500);
    int k = 0;

    for(int i=0;i<n;i++)
    {
        /* filtrer seulement ces 4 */
        if( strcasecmp(t[i].cours_nom,"Aerobic")!=0 &&
            strcasecmp(t[i].cours_nom,"yoga")!=0 &&
            strcasecmp(t[i].cours_nom,"pilates")!=0 &&
            strcasecmp(t[i].cours_nom,"zumba")!=0 )
            continue;

        int existe = 0;
        for(int j=0;j<k;j++)
            if(strcasecmp(noms[j], t[i].cours_nom)==0) existe = 1;

        if(!existe && k < max_noms)
        {
            strncpy(noms[k], t[i].cours_nom, 128-1);
            noms[k][128-1] = '\0';
            k++;
        }
    }
    return k;
}

int choisir_nom_cours(char *out, int outsz)
{
    char noms[20][128];
    int k = liste_noms_cours_prives(noms, 20);
    if(k <= 0)
    {
        printf("Aucun cours (Aerobic/yoga/pilates/zumba) de type Prive dans cours.txt\n");
        return 0;
    }

    printf("\nChoisir Nom du cours:\n");
    for(int i=0;i<k;i++)
        printf("%d - %s\n", i+1, noms[i]);

    int c = lire_int("Numero cours: ", 1, k);
    strncpy(out, noms[c-1], outsz-1);
    out[outsz-1] = '\0';
    return 1;
}

/* affiche toutes les offres correspondant au nom choisi, puis retourne l'index choisi dans t[] */
int afficher_offres_et_choisir(Cours t[], int n, const char *nom_cours)
{
    int idx_map[500];
    int m = 0;

    printf("\nOffres disponibles pour [%s] (type Prive):\n", nom_cours);

    for(int i=0;i<n;i++)
    {
        if(strcasecmp(t[i].cours_nom, nom_cours)==0)
        {
            m++;
            idx_map[m-1] = i;
            printf("%d) IDcours=%d | Entraineur=%s | Centre=%s | %dh | %s | %dh | %02d/%02d/%04d | %s\n",
                   m, t[i].id, t[i].entraineur, t[i].centre,
                   t[i].heure, t[i].jour, t[i].duree,
                   t[i].j, t[i].m, t[i].a, t[i].niveau);
        }
    }

    if(m == 0)
    {
        printf("Aucune offre trouvee pour ce cours.\n");
        return -1;
    }

    int c = lire_int("Choisir l'offre (numero): ", 1, m);
    return idx_map[c-1];
}
