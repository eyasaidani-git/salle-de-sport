#ifndef COURS_PRV_H_INCLUDED
#define COURS_PRV_H_INCLUDED

#include <stdio.h>

typedef struct
{
    int id_insc;                 /* auto */
    char membre[128];        /* nom prenom membre */
    int id_cours;                /* id du cours choisi (depuis cours.txt) */
    char cours[128];         /* Aerobic/yoga/pilates/zumba */
    char entraineur[128];
    char centre[128];
    int heure;
    char jour[128];
    int duree;
    int j, m, a;
    char niveau[128];
    char genre[128];         /* Mixte/Unisex */
} InscriptionPrv;

/* inscription (ajout) */
int prv_next_id(char *filename);
int prv_ajouter(char *filename, InscriptionPrv insc);

#endif
