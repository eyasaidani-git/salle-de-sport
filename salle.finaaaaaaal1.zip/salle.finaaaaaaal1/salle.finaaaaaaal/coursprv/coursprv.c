#include "coursprv.h"
#include <string.h>

int prv_next_id(char *filename)
{
    FILE *f = fopen(filename, "r");
    if(!f) return 1;

    int max_id = 0;
    InscriptionPrv x;

    while(fscanf(f,
        "%d;%127[^;];%d;%127[^;];%127[^;];%127[^;];%d;%127[^;];%d;%d/%d/%d;%127[^;];%127[^\n]\n",
        &x.id_insc, x.membre, &x.id_cours, x.cours, x.entraineur, x.centre,
        &x.heure, x.jour, &x.duree, &x.j, &x.m, &x.a, x.niveau, x.genre) != EOF)
    {
        if(x.id_insc > max_id) max_id = x.id_insc;
    }

    fclose(f);
    return max_id + 1;
}

/* format coursprv.txt:
   id_insc;membre;id_cours;cours;entraineur;centre;heure;jour;duree;JJ/MM/AAAA;niveau;genre
*/
int prv_ajouter(char *filename, InscriptionPrv insc)
{
    FILE *f = fopen(filename, "a");
    if(!f) return 0;

    fprintf(f, "%d;%s;%d;%s;%s;%s;%d;%s;%d;%02d/%02d/%04d;%s;%s\n",
            insc.id_insc, insc.membre, insc.id_cours, insc.cours,
            insc.entraineur, insc.centre, insc.heure, insc.jour,
            insc.duree, insc.j, insc.m, insc.a, insc.niveau, insc.genre);

    fclose(f);
    return 1;
}
