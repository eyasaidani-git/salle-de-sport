#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>
#include "reservation.h"
#include "equipement.h"

/* Enumération pour les colonnes du treeview des réservations */
enum {
    RES_COL_EQUIPEMENT = 0,
    RES_COL_TYPE_COURS,
    RES_COL_QUANTITE,
    RES_COL_SALLE,
    RES_COL_DATE,
    RES_COL_HEURE,
    RES_N_COLONNES
};

void reserver_equipment(int equipment_id, int user_id) {
    // Votre code pour la réservation
    printf("Réservation de l'équipement %d pour l'utilisateur %d\n", equipment_id, user_id);
}

/* Ajouter une réservation au fichier */
void ajouter_reservation(Reservation r) {
    FILE *f = fopen(FICHIER_RESERVATIONS, "a");
    if (f == NULL) {
        f = fopen(FICHIER_RESERVATIONS, "w");
        if (f == NULL) {
            printf("Erreur création fichier réservations\n");
            return;
        }
    }
    
    fprintf(f, "%d;%s;%s;%s;%s;%d;%d;%d;%d;%d;%d;%d\n",
            r.id_entraineur, r.salle, r.type_salle, r.type_cours,
            r.equipement, r.quantite, r.jour, r.mois, r.annee,
            r.heure, r.cours_public, r.coaching_prive);
    
    fclose(f);
}

/* Confirmer une réservation (sauvegarder le panier) */
void confirmer_reservation(int id_entraineur) {
    /* Cette fonction sera principalement appelée depuis callbacks.c
       après avoir collecté toutes les réservations du panier */
    printf("Réservation confirmée pour l'entraîneur %d\n", id_entraineur);
}

/* Annuler une réservation */
void annuler_reservation(int id_entraineur) {
    FILE *f = fopen(FICHIER_RESERVATIONS, "r");
    FILE *temp = fopen("temp_res.txt", "w");
    
    if (f == NULL || temp == NULL) {
        printf("Erreur ouverture fichiers réservations\n");
        if (f) fclose(f);
        if (temp) fclose(temp);
        return;
    }
    
    char ligne[256];
    int annulees = 0;
    
    while (fgets(ligne, sizeof(ligne), f)) {
        int id;
        sscanf(ligne, "%d", &id);
        
        if (id != id_entraineur) {
            fprintf(temp, "%s", ligne);
        } else {
            annulees++;
        }
    }
    
    fclose(f);
    fclose(temp);
    
    remove(FICHIER_RESERVATIONS);
    rename("temp_res.txt", FICHIER_RESERVATIONS);
    
    printf("%d réservation(s) annulée(s) pour l'entraîneur %d\n", annulees, id_entraineur);
}

/* Afficher les réservations dans le panier (treeview) */
void afficher_reservations_panier(GtkWidget *treeview) {
    /* Cette fonction est similaire à afficher_equipements()
       mais pour les réservations du panier actuel */
    printf("Affichage du panier de réservations\n");
}

/* Sauvegarder le contenu du panier */
void sauvegarder_panier(GtkWidget *treeview, int id_entraineur) {
    GtkTreeModel *model = gtk_tree_view_get_model(GTK_TREE_VIEW(treeview));
    if (model == NULL) {
        printf("Panier vide\n");
        return;
    }
    
    GtkTreeIter iter;
    gboolean valid = gtk_tree_model_get_iter_first(model, &iter);
    int count = 0;
    
    FILE *f = fopen("panier_temp.txt", "a");
    if (f == NULL) {
        f = fopen("panier_temp.txt", "w");
        if (f == NULL) {
            printf("Erreur création fichier panier\n");
            return;
        }
    }
    
    while (valid) {
        gchar *equipement, *type_cours, *salle;
        gint quantite;
        
        gtk_tree_model_get(model, &iter,
                          RES_COL_EQUIPEMENT, &equipement,
                          RES_COL_TYPE_COURS, &type_cours,
                          RES_COL_QUANTITE, &quantite,
                          RES_COL_SALLE, &salle,
                          -1);
        
        /* Créer une réservation temporaire */
        Reservation r;
        r.id_entraineur = id_entraineur;
        strcpy(r.equipement, equipement);
        strcpy(r.type_cours, type_cours);
        strcpy(r.salle, salle);
        r.quantite = quantite;
        /* Les autres champs peuvent être remplis ailleurs */
        
        /* Sauvegarder dans le fichier temporaire */
        fprintf(f, "%s;%s;%d;%s\n", equipement, type_cours, quantite, salle);
        
        g_free(equipement);
        g_free(type_cours);
        g_free(salle);
        
        count++;
        valid = gtk_tree_model_iter_next(model, &iter);
    }
    
    fclose(f);
    printf("%d élément(s) sauvegardé(s) dans le panier\n", count);
}

/* Vérifier la disponibilité d'un équipement */
int verifier_disponibilite(char *equipement, int quantite, int jour, int mois, int annee) {
    /* Cette fonction devrait vérifier dans le fichier des réservations
       si l'équipement est disponible à la date demandée */
    
    /* Pour l'instant, on retourne toujours disponible */
    return 1; /* 1 = disponible, 0 = non disponible */
}

