#ifndef EQUIPEMENT_H
#define EQUIPEMENT_H

#include <gtk/gtk.h>

#define MAX_EQUIPEMENTS 100
#define FICHIER_EQUIPEMENTS "equipements.txt"

typedef struct {
    char nom[50];
    char salle[50];
    char type_salle[20];
    char type_equipement[50];
    int jour;
    int mois;
    int annee;
    int quantite;
    int consommable; // 1 = oui, 0 = non
} Equipement;

/* Fonctions de gestion des équipements */
void ajouter_equipement(Equipement e);
void modifier_equipement(char *nom, Equipement nouveau);
void supprimer_equipement(char *nom);
void afficher_equipements(GtkWidget *treeview);
Equipement chercher_equipement_par_nom(char *nom);
int compter_equipements(void);
Equipement* chercher_equipements_par_salle(char *salle, int *nombre);

/* Fonction de réservation */
void reserver_equipment(int equipment_id, int user_id);

#endif

