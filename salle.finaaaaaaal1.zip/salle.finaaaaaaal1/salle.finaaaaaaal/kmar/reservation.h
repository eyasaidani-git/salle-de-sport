#ifndef RESERVATION_H
#define RESERVATION_H

#include <gtk/gtk.h>

#define MAX_RESERVATIONS 100
#define FICHIER_RESERVATIONS "reservations.txt"

typedef struct {
    int id_entraineur;
    char salle[50];
    char type_salle[20];
    char type_cours[50];
    char equipement[50];
    int quantite;
    int jour;
    int mois;
    int annee;
    int heure;
    int cours_public;    // 1 = oui, 0 = non
    int coaching_prive;  // 1 = oui, 0 = non
} Reservation;

/* Fonctions de gestion des réservations */
void ajouter_reservation(Reservation r);
void confirmer_reservation(int id_entraineur);
void annuler_reservation(int id_entraineur);
void afficher_reservations_panier(GtkWidget *treeview);
void sauvegarder_panier(GtkWidget *treeview, int id_entraineur);
int verifier_disponibilite(char *equipement, int quantite, int jour, int mois, int annee);

#endif

