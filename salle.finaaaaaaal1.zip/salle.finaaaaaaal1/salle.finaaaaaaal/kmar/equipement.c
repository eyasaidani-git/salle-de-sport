#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>
#include "equipement.h"

/* Enumération pour les colonnes du treeview */
enum {
    COL_NOM = 0,
    COL_SALLE,
    COL_TYPE_SALLE,
    COL_TYPE_EQUIPEMENT,
    COL_DATE,
    COL_QUANTITE,
    COL_CONSOMMABLE,
    N_COLONNES
};

/* Ajouter un équipement au fichier */
void ajouter_equipement(Equipement e) {
    FILE *f = fopen(FICHIER_EQUIPEMENTS, "a");
    if (f == NULL) {
        f = fopen(FICHIER_EQUIPEMENTS, "w");
        if (f == NULL) {
            printf("Erreur création fichier équipements\n");
            return;
        }
    }
    
    fprintf(f, "%s;%s;%s;%s;%d;%d;%d;%d;%d\n",
            e.nom, e.salle, e.type_salle, e.type_equipement,
            e.jour, e.mois, e.annee, e.quantite, e.consommable);
    
    fclose(f);
}

/* Modifier un équipement existant */
void modifier_equipement(char *nom, Equipement nouveau) {
    FILE *f = fopen(FICHIER_EQUIPEMENTS, "r");
    FILE *temp = fopen("temp.txt", "w");
    
    if (f == NULL || temp == NULL) {
        printf("Erreur ouverture fichiers\n");
        if (f) fclose(f);
        if (temp) fclose(temp);
        return;
    }
    
    char ligne[256];
    int modifie = 0;
    
    while (fgets(ligne, sizeof(ligne), f)) {
        char nom_fichier[50];
        sscanf(ligne, "%[^;]", nom_fichier);
        
        if (strcmp(nom_fichier, nom) == 0) {
            /* Remplacer par la nouvelle version */
            fprintf(temp, "%s;%s;%s;%s;%d;%d;%d;%d;%d\n",
                    nouveau.nom, nouveau.salle, nouveau.type_salle, 
                    nouveau.type_equipement, nouveau.jour, nouveau.mois,
                    nouveau.annee, nouveau.quantite, nouveau.consommable);
            modifie = 1;
        } else {
            /* Copier la ligne inchangée */
            fprintf(temp, "%s", ligne);
        }
    }
    
    fclose(f);
    fclose(temp);
    
    /* Remplacer l'ancien fichier par le nouveau */
    remove(FICHIER_EQUIPEMENTS);
    rename("temp.txt", FICHIER_EQUIPEMENTS);
    
    if (modifie) {
        printf("Équipement '%s' modifié\n", nom);
    } else {
        printf("Équipement '%s' non trouvé\n", nom);
    }
}

/* Supprimer un équipement */
void supprimer_equipement(char *nom) {
    FILE *f = fopen(FICHIER_EQUIPEMENTS, "r");
    FILE *temp = fopen("temp.txt", "w");
    
    if (f == NULL || temp == NULL) {
        printf("Erreur ouverture fichiers\n");
        if (f) fclose(f);
        if (temp) fclose(temp);
        return;
    }
    
    char ligne[256];
    int supprime = 0;
    
    while (fgets(ligne, sizeof(ligne), f)) {
        char nom_fichier[50];
        sscanf(ligne, "%[^;]", nom_fichier);
        
        if (strcmp(nom_fichier, nom) == 0) {
            supprime = 1;
        } else {
            fprintf(temp, "%s", ligne);
        }
    }
    
    fclose(f);
    fclose(temp);
    
    remove(FICHIER_EQUIPEMENTS);
    rename("temp.txt", FICHIER_EQUIPEMENTS);
    
    if (supprime) {
        printf("Équipement '%s' supprimé\n", nom);
    } else {
        printf("Équipement '%s' non trouvé\n", nom);
    }
}

/* Afficher tous les équipements dans un treeview */
void afficher_equipements(GtkWidget *treeview) {
    GtkCellRenderer *renderer;
    GtkTreeViewColumn *column;
    GtkTreeIter iter;
    GtkListStore *store;
    
    /* Créer le modèle si nécessaire */
    store = GTK_LIST_STORE(gtk_tree_view_get_model(GTK_TREE_VIEW(treeview)));
    if (store == NULL) {
        /* Créer les colonnes */
        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Nom", renderer, "text", COL_NOM, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);
        
        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Salle", renderer, "text", COL_SALLE, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);
        
        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Type Salle", renderer, "text", COL_TYPE_SALLE, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);
        
        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Type Équipement", renderer, "text", COL_TYPE_EQUIPEMENT, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);
        
        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Date", renderer, "text", COL_DATE, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);
        
        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Quantité", renderer, "text", COL_QUANTITE, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);
        
        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Consommable", renderer, "text", COL_CONSOMMABLE, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);
        
        /* Créer le store */
        store = gtk_list_store_new(N_COLONNES,
                                  G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,
                                  G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT,
                                  G_TYPE_STRING);
    } else {
        /* Vider le store existant */
        gtk_list_store_clear(store);
    }
    
    /* Lire le fichier et remplir le store */
    FILE *f = fopen(FICHIER_EQUIPEMENTS, "r");
    if (f == NULL) {
        gtk_tree_view_set_model(GTK_TREE_VIEW(treeview), GTK_TREE_MODEL(store));
        g_object_unref(store);
        return;
    }
    
    char ligne[256];
    while (fgets(ligne, sizeof(ligne), f)) {
        Equipement e;
        char consommable[10];
        
        sscanf(ligne, "%[^;];%[^;];%[^;];%[^;];%d;%d;%d;%d;%d",
               e.nom, e.salle, e.type_salle, e.type_equipement,
               &e.jour, &e.mois, &e.annee, &e.quantite, &e.consommable);
        
        gtk_list_store_append(store, &iter);
        
        char date_str[20];
        sprintf(date_str, "%d/%d/%d", e.jour, e.mois, e.annee);
        
        char quantite_str[10];
        sprintf(quantite_str, "%d", e.quantite);
        
        strcpy(consommable, e.consommable ? "OUI" : "NON");
        
        gtk_list_store_set(store, &iter,
                          COL_NOM, e.nom,
                          COL_SALLE, e.salle,
                          COL_TYPE_SALLE, e.type_salle,
                          COL_TYPE_EQUIPEMENT, e.type_equipement,
                          COL_DATE, date_str,
                          COL_QUANTITE, quantite_str,
                          COL_CONSOMMABLE, consommable,
                          -1);
    }
    
    fclose(f);
    gtk_tree_view_set_model(GTK_TREE_VIEW(treeview), GTK_TREE_MODEL(store));
    g_object_unref(store);
}

/* Chercher un équipement par son nom */
Equipement chercher_equipement_par_nom(char *nom) {
    Equipement e;
    memset(&e, 0, sizeof(Equipement)); /* Initialiser à zéro */
    
    FILE *f = fopen(FICHIER_EQUIPEMENTS, "r");
    if (f == NULL) {
        return e;
    }
    
    char ligne[256];
    int trouve = 0;
    
    while (fgets(ligne, sizeof(ligne), f) && !trouve) {
        char nom_fichier[50];
        sscanf(ligne, "%[^;]", nom_fichier);
        
        if (strcmp(nom_fichier, nom) == 0) {
            sscanf(ligne, "%[^;];%[^;];%[^;];%[^;];%d;%d;%d;%d;%d",
                   e.nom, e.salle, e.type_salle, e.type_equipement,
                   &e.jour, &e.mois, &e.annee, &e.quantite, &e.consommable);
            trouve = 1;
        }
    }
    
    fclose(f);
    return e;
}

/* Compter le nombre total d'équipements */
int compter_equipements(void) {
    FILE *f = fopen(FICHIER_EQUIPEMENTS, "r");
    if (f == NULL) {
        return 0;
    }
    
    int count = 0;
    char ligne[256];
    
    while (fgets(ligne, sizeof(ligne), f)) {
        count++;
    }
    
    fclose(f);
    return count;
}

