#ifndef COURSSPORTIF_H_INCLUDED
#define COURSSPORTIF_H_INCLUDED

#include <stdio.h>


typedef struct
{
    int id;                       // auto
    int cours_num;                // 1..4 (yoga/judo/pedales/dance)
    char cours_nom[20];           // "yoga" ...
    char entraineur[128];     // "Ahmed Ben Ali" (champ avant ';')
    char centre[128];         // "Next level spot (bardo)" ...
    int heure;                    // 8..23
    char jour[15];                // Lundi..Dimanche
    int duree;                    // 1..3
    int date_j, date_m, date_a;   // j 1..31, m 1..12, a>=2025
    char niveau[20];              // "Debutant" | "Intermediaire" | "Avance"
    char type[10];                // "Publique" | "Prive"
} CoursSportif;

/* CRUD fichier cours.txt */
int cs_ajouter(const char *filename, CoursSportif cs);
int cs_modifier(const char *filename, int id, CoursSportif nouv);
int cs_supprimer(const char *filename, int id);
CoursSportif cs_chercher(const char *filename, int id);

/* utilitaires */
int cs_next_id(const char *filename);                 // max(id)+1
int cs_valider(const CoursSportif *cs, char *err);    // err[MAX_STR]
const char* cs_cours_nom_from_num(int n);             // 1..4 -> "yoga"...

#endif
