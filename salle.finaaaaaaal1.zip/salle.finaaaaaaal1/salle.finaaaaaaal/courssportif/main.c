#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "courssportif.h"

#define F_COURS "cours.txt"
#define F_ENTRAINEURS "entraineurs.txt"
#define F_CENTRES "centres.txt"

/* Prototypes */
void afficher_menu(void);
int lire_int(const char *msg, int min, int max);

void afficher_liste_cours(void);
int choisir_cours_num(void);
void choisir_entraineur(char *out, int outsz);
void choisir_centre(char *out, int outsz);
void choisir_jour(char *out, int outsz);
void choisir_niveau(char *out, int outsz);
void choisir_type(char *out, int outsz);

CoursSportif saisir_cours_sans_id(void);
void afficher_cours(const CoursSportif *cs);

/* ===== main ===== */
int main(void)
{
    int choix;

    do {
        afficher_menu();
        choix = lire_int("Votre choix: ", 0, 4);

        switch(choix)
        {
            case 1: /* AJOUT */
            {
                CoursSportif cs = saisir_cours_sans_id();
                cs.id = cs_next_id(F_COURS);
                strncpy(cs.cours_nom, cs_cours_nom_from_num(cs.cours_num), sizeof(cs.cours_nom)-1);

                char err[128];
                if(!cs_valider(&cs, err))
                {
                    printf("Erreur: %s\n", err);
                    break;
                }

                if(cs_ajouter(F_COURS, cs))
                    printf("OK: cours ajoute. ID auto = %d\n", cs.id);
                else
                    printf("Erreur: echec ajout.\n");
            }
            break;

            case 2: /* MODIF */
            {
                int id = lire_int("Donner ID a modifier: ", 1, 1000000);
                CoursSportif old = cs_chercher(F_COURS, id);
                if(old.id == -1)
                {
                    printf("Introuvable.\n");
                    break;
                }

                printf("Cours actuel:\n");
                afficher_cours(&old);

                CoursSportif nouv = saisir_cours_sans_id();
                nouv.id = id;
                strncpy(nouv.cours_nom, cs_cours_nom_from_num(nouv.cours_num), sizeof(nouv.cours_nom)-1);

                char err[128];
                if(!cs_valider(&nouv, err))
                {
                    printf("Erreur: %s\n", err);
                    break;
                }

                if(cs_modifier(F_COURS, id, nouv))
                    printf("OK: cours modifie.\n");
                else
                    printf("Erreur: echec modification.\n");
            }
            break;

            case 3: /* SUPPR */
            {
                int id = lire_int("Donner ID a supprimer: ", 1, 1000000);
                if(cs_supprimer(F_COURS, id))
                    printf("OK: cours supprime.\n");
                else
                    printf("Introuvable.\n");
            }
            break;

            case 4: /* RECH */
            {
                int id = lire_int("Donner ID a chercher: ", 1, 1000000);
                CoursSportif cs = cs_chercher(F_COURS, id);
                if(cs.id == -1) printf("Introuvable.\n");
                else afficher_cours(&cs);
            }
            break;

            case 0:
                printf("Au revoir.\n");
            break;
        }

    } while(choix != 0);

    return 0;
}

/* ===== Fonctions ===== */

void afficher_menu(void)
{
    printf("\n========== Gestion Cours Sportifs ==========\n");
    printf("1) Ajouter un cours\n");
    printf("2) Modifier un cours\n");
    printf("3) Supprimer un cours\n");
    printf("4) Rechercher un cours (par ID)\n");
    printf("0) Quitter\n");
    printf("===========================================\n");
}

int lire_int(const char *msg, int min, int max)
{
    int x;
    do {
        printf("%s", msg);
        if(scanf("%d", &x) != 1)
        {
            while(getchar() != '\n');
            x = min - 1;
        }
        else
        {
            while(getchar() != '\n');
        }
    } while(x < min || x > max);
    return x;
}

void afficher_liste_cours(void)
{
    printf("1 - Aerobic\n");
    printf("2 - yoga\n");
    printf("3 - pilates\n");
    printf("4 - zumba\n");
}

int choisir_cours_num(void)
{
    printf("\nChoisir Nom de cours:\n");
    afficher_liste_cours();
    return lire_int("Numero cours (1..4): ", 1, 4);
}

void choisir_entraineur(char *out, int outsz)
{
    FILE *f = fopen(F_ENTRAINEURS, "r");
    if(!f) { printf("Erreur: entraineurs.txt introuvable.\n"); out[0]='\0'; return; }

    char noms[200][128];
    int n = 0;
    char line[512];

    while(fgets(line, sizeof(line), f) && n < 200)
    {
        char *p = strchr(line, ';');
        if(p) *p = '\0';
        line[strcspn(line, "\r\n")] = '\0';

        if(strlen(line) > 0)
        {
            strncpy(noms[n], line, 128-1);
            noms[n][128-1] = '\0';
            n++;
        }
    }
    fclose(f);

    if(n == 0) { printf("Aucun entraineur.\n"); out[0]='\0'; return; }

    printf("\nChoisir Entraineur:\n");
    for(int i=0;i<n;i++) printf("%d - %s\n", i+1, noms[i]);

    int ch = lire_int("Numero entraineur: ", 1, n);
    strncpy(out, noms[ch-1], outsz-1);
    out[outsz-1] = '\0';
}

void choisir_centre(char *out, int outsz)
{
    FILE *f = fopen(F_CENTRES, "r");
    if(!f) { printf("Erreur: centres.txt introuvable.\n"); out[0]='\0'; return; }

    char centres[200][128];
    int n = 0;
    char line[512];

    while(fgets(line, sizeof(line), f) && n < 200)
    {
        char *q1 = strchr(line, '"'); if(!q1) continue;
        char *q2 = strchr(q1+1, '"'); if(!q2) continue;
        char *q3 = strchr(q2+1, '"'); if(!q3) continue;
        char *q4 = strchr(q3+1, '"'); if(!q4) continue;

        char ville[64];
        int len = (int)(q4 - (q3+1));
        if(len <= 0 || len >= (int)sizeof(ville)) continue;

        strncpy(ville, q3+1, len);
        ville[len] = '\0';

        while(ville[0]==' ') memmove(ville, ville+1, strlen(ville));
        for(int i=(int)strlen(ville)-1; i>=0 && ville[i]==' '; --i) ville[i]='\0';

        snprintf(centres[n], 128, "Next level spot (%s)", ville);
        n++;
    }
    fclose(f);

    if(n == 0) { printf("Aucun centre.\n"); out[0]='\0'; return; }

    printf("\nChoisir Centre sportif:\n");
    for(int i=0;i<n;i++) printf("%d - %s\n", i+1, centres[i]);

    int ch = lire_int("Numero centre: ", 1, n);
    strncpy(out, centres[ch-1], outsz-1);
    out[outsz-1] = '\0';
}

void choisir_jour(char *out, int outsz)
{
    const char *jours[] = {"Lundi","Mardi","Mercredi","Jeudi","Vendredi","Samedi","Dimanche"};
    printf("\nChoisir Jour:\n");
    for(int i=0;i<7;i++) printf("%d - %s\n", i+1, jours[i]);
    int ch = lire_int("Numero jour: ", 1, 7);
    strncpy(out, jours[ch-1], outsz-1);
    out[outsz-1] = '\0';
}

void choisir_niveau(char *out, int outsz)
{
    printf("\nChoisir Niveau:\n");
    printf("1 - Debutant\n");
    printf("2 - Intermediaire\n");
    printf("3 - Avance\n");
    int ch = lire_int("Numero niveau: ", 1, 3);

    if(ch==1) strncpy(out, "Debutant", outsz-1);
    else if(ch==2) strncpy(out, "Intermediaire", outsz-1);
    else strncpy(out, "Avance", outsz-1);

    out[outsz-1] = '\0';
}

void choisir_type(char *out, int outsz)
{
    printf("\nType de cours:\n");
    printf("1 - Publique\n");
    printf("2 - Prive\n");
    int ch = lire_int("Numero type: ", 1, 2);

    if(ch==1) strncpy(out, "Publique", outsz-1);
    else strncpy(out, "Prive", outsz-1);

    out[outsz-1] = '\0';
}

CoursSportif saisir_cours_sans_id(void)
{
    CoursSportif cs;
    memset(&cs, 0, sizeof(cs));

    cs.cours_num = choisir_cours_num();
    choisir_entraineur(cs.entraineur, sizeof(cs.entraineur));
    choisir_centre(cs.centre, sizeof(cs.centre));

    cs.heure = lire_int("Heure (8..23): ", 8, 23);
    choisir_jour(cs.jour, sizeof(cs.jour));
    cs.duree = lire_int("Duree (1..3): ", 1, 3);

    printf("\nDate:\n");
    cs.date_j = lire_int("Jour (1..31): ", 1, 31);
    cs.date_m = lire_int("Mois (1..12): ", 1, 12);
    cs.date_a = lire_int("Annee (>=2025): ", 2025, 2100);

    choisir_niveau(cs.niveau, sizeof(cs.niveau));
    choisir_type(cs.type, sizeof(cs.type));

    return cs;
}

void afficher_cours(const CoursSportif *cs)
{
    printf("\n----- Cours sportif -----\n");
    printf("ID: %d\n", cs->id);
    printf("Cours: %d - %s\n", cs->cours_num, cs->cours_nom);
    printf("Entraineur: %s\n", cs->entraineur);
    printf("Centre: %s\n", cs->centre);
    printf("Heure: %d\n", cs->heure);
    printf("Jour: %s\n", cs->jour);
    printf("Duree: %d\n", cs->duree);
    printf("Date: %02d/%02d/%04d\n", cs->date_j, cs->date_m, cs->date_a);
    printf("Niveau: %s\n", cs->niveau);
    printf("Type: %s\n", cs->type);
    printf("-------------------------\n");
}
