#include "courssportif.h"
#include <string.h>
#include <stdlib.h>

/* Plus de static */
void cs_init_introuvable(CoursSportif *cs)
{
    memset(cs, 0, sizeof(*cs));
    cs->id = -1;
}

const char* cs_cours_nom_from_num(int n)
{
    switch(n)
    {
        case 1: return "Aerobic";
        case 2: return "yoga";
        case 3: return "pilates";
        case 4: return "zumba";
        default: return "unknown";

    }
}

int cs_valider(const CoursSportif *cs, char *err)
{
    if(!cs) { strcpy(err, "Cours NULL"); return 0; }

    if(cs->cours_num < 1 || cs->cours_num > 4) { strcpy(err, "Nom de cours invalide"); return 0; }
    if(cs->heure < 8 || cs->heure > 23) { strcpy(err, "Heure invalide (8..23)"); return 0; }
    if(cs->duree < 1 || cs->duree > 3) { strcpy(err, "Durée invalide (1..3)"); return 0; }
    if(cs->date_j < 1 || cs->date_j > 31) { strcpy(err, "Jour invalide (1..31)"); return 0; }
    if(cs->date_m < 1 || cs->date_m > 12) { strcpy(err, "Mois invalide (1..12)"); return 0; }
    if(cs->date_a < 2025) { strcpy(err, "Année invalide (>=2025)"); return 0; }

    if(strlen(cs->entraineur) == 0) { strcpy(err, "Entraîneur obligatoire"); return 0; }
    if(strlen(cs->centre) == 0) { strcpy(err, "Centre obligatoire"); return 0; }
    if(strlen(cs->jour) == 0) { strcpy(err, "Jour obligatoire"); return 0; }

    if(strcmp(cs->niveau, "Debutant")!=0 &&
       strcmp(cs->niveau, "Intermediaire")!=0 &&
       strcmp(cs->niveau, "Avance")!=0)
    { strcpy(err, "Niveau invalide"); return 0; }

    if(strcmp(cs->type, "Publique")!=0 && strcmp(cs->type, "Prive")!=0)
    { strcpy(err, "Type invalide"); return 0; }

    strcpy(err, "OK");
    return 1;
}

int cs_next_id(const char *filename)
{
    FILE *f = fopen(filename, "r");
    if(!f) return 1; /* si fichier n'existe pas -> id=1 */

    int max_id = 0;
    CoursSportif cs;

    while(fscanf(f,
        "%d;%d;%19[^;];%127[^;];%127[^;];%d;%14[^;];%d;%d/%d/%d;%19[^;];%9[^\n]\n",
        &cs.id, &cs.cours_num, cs.cours_nom,
        cs.entraineur, cs.centre,
        &cs.heure, cs.jour,
        &cs.duree, &cs.date_j, &cs.date_m, &cs.date_a,
        cs.niveau, cs.type) != EOF)
    {
        if(cs.id > max_id) max_id = cs.id;
    }

    fclose(f);
    return max_id + 1;
}

/* Format cours.txt :
   id;cours_num;cours_nom;entraineur;centre;heure;jour;duree;JJ/MM/AAAA;niveau;type
*/

int cs_ajouter(const char *filename, CoursSportif cs)
{
    char err[128];
    if(!cs_valider(&cs, err)) return 0;

    FILE *f = fopen(filename, "a");
    if(!f) return 0;

    fprintf(f, "%d;%d;%s;%s;%s;%d;%s;%d;%02d/%02d/%04d;%s;%s\n",
        cs.id, cs.cours_num, cs.cours_nom,
        cs.entraineur, cs.centre,
        cs.heure, cs.jour,
        cs.duree, cs.date_j, cs.date_m, cs.date_a,
        cs.niveau, cs.type);

    fclose(f);
    return 1;
}

int cs_modifier(const char *filename, int id, CoursSportif nouv)
{
    int tr = 0;
    FILE *f = fopen(filename, "r");
    FILE *f2 = fopen("nouv.txt", "w");
    if(!f || !f2)
    {
        if(f) fclose(f);
        if(f2) fclose(f2);
        return 0;
    }

    CoursSportif cs;
    while(fscanf(f,
        "%d;%d;%19[^;];%127[^;];%127[^;];%d;%14[^;];%d;%d/%d/%d;%19[^;];%9[^\n]\n",
        &cs.id, &cs.cours_num, cs.cours_nom,
        cs.entraineur, cs.centre,
        &cs.heure, cs.jour,
        &cs.duree, &cs.date_j, &cs.date_m, &cs.date_a,
        cs.niveau, cs.type) != EOF)
    {
        if(cs.id == id)
        {
            fprintf(f2, "%d;%d;%s;%s;%s;%d;%s;%d;%02d/%02d/%04d;%s;%s\n",
                nouv.id, nouv.cours_num, nouv.cours_nom,
                nouv.entraineur, nouv.centre,
                nouv.heure, nouv.jour,
                nouv.duree, nouv.date_j, nouv.date_m, nouv.date_a,
                nouv.niveau, nouv.type);
            tr = 1;
        }
        else
        {
            fprintf(f2, "%d;%d;%s;%s;%s;%d;%s;%d;%02d/%02d/%04d;%s;%s\n",
                cs.id, cs.cours_num, cs.cours_nom,
                cs.entraineur, cs.centre,
                cs.heure, cs.jour,
                cs.duree, cs.date_j, cs.date_m, cs.date_a,
                cs.niveau, cs.type);
        }
    }

    fclose(f);
    fclose(f2);
    remove(filename);
    rename("nouv.txt", filename);
    return tr;
}

int cs_supprimer(const char *filename, int id)
{
    int tr = 0;
    FILE *f = fopen(filename, "r");
    FILE *f2 = fopen("nouv.txt", "w");
    if(!f || !f2)
    {
        if(f) fclose(f);
        if(f2) fclose(f2);
        return 0;
    }

    CoursSportif cs;
    while(fscanf(f,
        "%d;%d;%19[^;];%127[^;];%127[^;];%d;%14[^;];%d;%d/%d/%d;%19[^;];%9[^\n]\n",
        &cs.id, &cs.cours_num, cs.cours_nom,
        cs.entraineur, cs.centre,
        &cs.heure, cs.jour,
        &cs.duree, &cs.date_j, &cs.date_m, &cs.date_a,
        cs.niveau, cs.type) != EOF)
    {
        if(cs.id == id)
            tr = 1;
        else
            fprintf(f2, "%d;%d;%s;%s;%s;%d;%s;%d;%02d/%02d/%04d;%s;%s\n",
                cs.id, cs.cours_num, cs.cours_nom,
                cs.entraineur, cs.centre,
                cs.heure, cs.jour,
                cs.duree, cs.date_j, cs.date_m, cs.date_a,
                cs.niveau, cs.type);
    }

    fclose(f);
    fclose(f2);
    remove(filename);
    rename("nouv.txt", filename);
    return tr;
}

CoursSportif cs_chercher(const char *filename, int id)
{
    CoursSportif cs;
    cs_init_introuvable(&cs);

    FILE *f = fopen(filename, "r");
    if(!f) return cs;

    while(fscanf(f,
        "%d;%d;%19[^;];%127[^;];%127[^;];%d;%14[^;];%d;%d/%d/%d;%19[^;];%9[^\n]\n",
        &cs.id, &cs.cours_num, cs.cours_nom,
        cs.entraineur, cs.centre,
        &cs.heure, cs.jour,
        &cs.duree, &cs.date_j, &cs.date_m, &cs.date_a,
        cs.niveau, cs.type) != EOF)
    {
        if(cs.id == id)
        {
            fclose(f);
            return cs;
        }
    }

    fclose(f);
    cs_init_introuvable(&cs);
    return cs;
}
